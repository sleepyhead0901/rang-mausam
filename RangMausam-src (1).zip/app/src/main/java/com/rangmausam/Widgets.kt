package com.rangmausam

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.widget.RemoteViews
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.TimeZone
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.sqrt

/** Settings for the newer widgets, next to the weather ones in the same SharedPreferences file. */
object More {
    private fun sp(c: Context) = c.getSharedPreferences("rang_mausam", Context.MODE_PRIVATE)

    // two-window clock: the "home" window
    fun homeCity(c: Context) = sp(c).getString("home_city", "Bengaluru") ?: "Bengaluru"
    fun homeLat(c: Context) = sp(c).getFloat("home_lat", 12.9716f).toDouble()
    fun homeLon(c: Context) = sp(c).getFloat("home_lon", 77.5946f).toDouble()
    fun homeZone(c: Context) = sp(c).getString("home_zone", "Asia/Kolkata") ?: "Asia/Kolkata"
    fun setHome(c: Context, g: Weather.Geo) = sp(c).edit().putString("home_city", g.name).putFloat("home_lat", g.lat.toFloat())
        .putFloat("home_lon", g.lon.toFloat()).putString("home_zone", g.zone).apply()

    // steps
    fun goal(c: Context) = sp(c).getInt("step_goal", 6000)
    fun setGoal(c: Context, v: Int) = sp(c).edit().putInt("step_goal", v).apply()
    fun stepsToday(c: Context): Int = if (sp(c).getLong("step_day", -1) == LocalDate.now().toEpochDay()) sp(c).getInt("step_today", 0) else 0
    fun wariKm(c: Context): Double = sp(c).getLong("step_total", 0) * 0.75 / 1000

    /** Folds a raw step-counter reading (steps since boot) into today's count and the running total. */
    fun recordSteps(c: Context, raw: Float) {
        val p = sp(c); val today = LocalDate.now().toEpochDay()
        val last = p.getFloat("step_last", -1f)
        var day = p.getLong("step_day", today); var todayCount = p.getInt("step_today", 0); var total = p.getLong("step_total", 0)
        val delta = when { last < 0f -> 0; raw >= last -> (raw - last).toInt(); else -> raw.toInt() } // counter resets on reboot
        if (day != today) { day = today; todayCount = 0 }
        todayCount += delta; total += delta
        p.edit().putFloat("step_last", raw).putLong("step_day", day).putInt("step_today", todayCount).putLong("step_total", total).apply()
    }

    // proverbs
    fun proverbLangs(c: Context): Set<String> = sp(c).getStringSet("prov_langs", null)?.toSet() ?: Proverbs.LANG_NAMES.keys
    fun setProverbLangs(c: Context, s: Set<String>) = sp(c).edit().putStringSet("prov_langs", s).apply()
    fun proverbOffset(c: Context): Int = if (sp(c).getLong("prov_day", -1) == LocalDate.now().toEpochDay()) sp(c).getInt("prov_off", 0) else 0
    fun nextProverb(c: Context) = sp(c).edit().putLong("prov_day", LocalDate.now().toEpochDay()).putInt("prov_off", proverbOffset(c) + 1).apply()
}

/** Plumbing shared by the widgets: sizes, bitmaps, alarms, intents. */
object W {
    class Size(val w: Double, val h: Double)

    fun size(c: Context, mgr: AppWidgetManager, id: Int, defW: Double, defH: Double): Size {
        val o: Bundle = mgr.getAppWidgetOptions(id)
        val portrait = c.resources.configuration.orientation != android.content.res.Configuration.ORIENTATION_LANDSCAPE
        var w = (if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH)).toDouble()
        var h = (if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)).toDouble()
        if (w <= 0) w = defW; if (h <= 0) h = defH
        return Size(w, h)
    }

    /** Draws at the widget's own size, capped so the bitmap stays well inside the RemoteViews memory limit. */
    fun bitmap(c: Context, s: Size, draw: Ink.() -> Unit): Bitmap {
        val d = c.resources.displayMetrics.density.toDouble()
        val cap = sqrt(2_400_000.0 / (s.w * s.h))
        val scale = minOf(d, cap).coerceAtLeast(1.0).toFloat()
        return Art.canvas(s.w, s.h, Store.fonts(c), scale, 20f, draw)
    }

    fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun self(c: Context, cls: Class<*>, action: String, code: Int): PendingIntent {
        val i = Intent(c, cls); i.action = action
        val ids = AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Wake the widget near [at] (within ten minutes); needs no exact-alarm permission. */
    fun wakeAt(c: Context, cls: Class<*>, at: Long, code: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setWindow(AlarmManager.RTC, at, 10 * 60_000L, self(c, cls, AppWidgetManager.ACTION_APPWIDGET_UPDATE, code))
    }

    fun ids(c: Context, cls: Class<*>): IntArray = AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))

    fun timeLabel(t: ZonedDateTime): String = "${if (t.hour % 12 == 0) 12 else t.hour % 12}:${t.minute.toString().padStart(2, '0')} ${if (t.hour < 12) "am" else "pm"}"

    /** Redraws every Rang Mausam widget (used by the app's Refresh button). */
    fun refreshAll(c: Context) {
        RangWidget.updateAll(c)
        Thread {
            val mgr = AppWidgetManager.getInstance(c)
            RagaWidget.draw(c, mgr, ids(c, RagaWidget::class.java))
            TwoWindowWidget.draw(c, mgr, ids(c, TwoWindowWidget::class.java))
            ProverbWidget.draw(c, mgr, ids(c, ProverbWidget::class.java))
            StepsWidget.draw(c, mgr, ids(c, StepsWidget::class.java))
        }.start()
    }
}

/** Base class: every update runs off the main thread. */
abstract class AsyncWidget : AppWidgetProvider() {
    abstract fun work(c: Context, mgr: AppWidgetManager, ids: IntArray)
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val p = goAsync()
        Thread { try { work(context, appWidgetManager, appWidgetIds) } catch (e: Exception) { } finally { p.finish() } }.start()
    }
    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) =
        onUpdate(context, appWidgetManager, intArrayOf(appWidgetId))
}

// ---------------------------------------------------------------------
class RagaWidget : AsyncWidget() {
    override fun work(c: Context, mgr: AppWidgetManager, ids: IntArray) = draw(c, mgr, ids)
    companion object {
        fun draw(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val now = LocalTime.now()
            val r = Ragas.at(now.hour)
            val mins = ((now.hour - r.start + 24) % 24) * 60 + now.minute
            for (id in ids) {
                val s = W.size(c, mgr, id, 250.0, 110.0)
                val rv = RemoteViews(c.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.widget_image, W.bitmap(c, s) { ragaWidget(s.w, s.h, r, mins / 120.0, "") })
                rv.setContentDescription(R.id.widget_image, "Raga of the hour: ${r.name}, ${r.period}. ${r.mood}.")
                val listen = PendingIntent.getActivity(c, 2, Intent(Intent.ACTION_VIEW, Uri.parse(Ragas.searchUrl(r))),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                rv.setOnClickPendingIntent(R.id.widget_image, listen)
                mgr.updateAppWidget(id, rv)
            }
            // redraw at the next even hour, when the raga changes (and halfway, to move the sun)
            val next = ZonedDateTime.now().withMinute(0).withSecond(0).withNano(0).plusHours(if (now.hour % 2 == 0) 1 else 1)
            W.wakeAt(c, RagaWidget::class.java, next.toInstant().toEpochMilli() + 30_000, 11)
        }
    }
}

// ---------------------------------------------------------------------
class StepsWidget : AsyncWidget() {
    override fun work(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        readSensor(c)
        draw(c, mgr, ids)
        // keep counting through the day: a gentle repeating wake-up every 15 minutes
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME, android.os.SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_FIFTEEN_MINUTES,
            AlarmManager.INTERVAL_FIFTEEN_MINUTES, W.self(c, StepsWidget::class.java, AppWidgetManager.ACTION_APPWIDGET_UPDATE, 21))
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(W.self(context, StepsWidget::class.java, AppWidgetManager.ACTION_APPWIDGET_UPDATE, 21))
    }

    companion object {
        fun permitted(c: Context) = Build.VERSION.SDK_INT < 29 ||
            c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

        /** Reads the hardware step counter once (it reports steps since boot) and folds it into today's total. */
        fun readSensor(c: Context): Boolean {
            if (!permitted(c)) return false
            val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return false
            val latch = CountDownLatch(1); var value = -1f
            val thread = HandlerThread("rang-steps"); thread.start()
            val l = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) { value = event.values[0]; latch.countDown() }
                override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL, Handler(thread.looper))
            latch.await(4, TimeUnit.SECONDS)
            sm.unregisterListener(l); thread.quitSafely()
            if (value >= 0f) More.recordSteps(c, value)
            return value >= 0f
        }

        fun draw(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val hasSensor = (c.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
            for (id in ids) {
                val s = W.size(c, mgr, id, 250.0, 110.0)
                val rv = RemoteViews(c.packageName, R.layout.widget)
                val steps = More.stepsToday(c)
                rv.setImageViewBitmap(R.id.widget_image, W.bitmap(c, s) {
                    if (!hasSensor) { paperBg(s.w, s.h, "#8A4B2E", "#2A1206"); text("This phone has no step sensor", 16.0, s.h / 2 - 8, s.w - 32, 20.0, fonts.sansBold, 10.0, "#F6EBD3", Ink.Align.CENTER) }
                    else stepsWidget(s.w, s.h, steps, More.goal(c), More.wariKm(c), Store.lang(c), !permitted(c))
                })
                rv.setContentDescription(R.id.widget_image, "$steps steps today, goal ${More.goal(c)}")
                rv.setOnClickPendingIntent(R.id.widget_image, if (permitted(c)) W.self(c, StepsWidget::class.java, AppWidgetManager.ACTION_APPWIDGET_UPDATE, 22) else W.openApp(c))
                mgr.updateAppWidget(id, rv)
            }
        }
    }
}

// ---------------------------------------------------------------------
class TwoWindowWidget : AsyncWidget() {
    override fun work(c: Context, mgr: AppWidgetManager, ids: IntArray) = draw(c, mgr, ids)
    companion object {
        private fun subtitle(lat: Double, lon: Double, zone: String, utc: Long): String {
            val alt = Sky.sun(lat, lon, utc).altitude
            val rising = alt < -0.83
            val t = Sky.nextCrossing(lat, lon, utc, rising) ?: return if (alt > 0) "sun up all day" else "polar night"
            return (if (rising) "sunrise " else "sunset ") + W.timeLabel(ZonedDateTime.ofInstant(Instant.ofEpochMilli(t), ZoneId.of(zone)))
        }

        private fun diff(hereZone: String, homeZone: String, utc: Long): String {
            val i = Instant.ofEpochMilli(utc)
            val secs = ZoneId.of(homeZone).rules.getOffset(i).totalSeconds - ZoneId.of(hereZone).rules.getOffset(i).totalSeconds
            if (secs == 0) return "same"
            val m = abs(secs) / 60
            return (if (secs > 0) "+" else "−") + "${m / 60}" + (if (m % 60 != 0) ":${(m % 60).toString().padStart(2, '0')}" else "h")
        }

        fun draw(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val utc = System.currentTimeMillis()
            val hereZone = TimeZone.getDefault().id
            val here = WindowSpec(Store.place(c), Store.lat(c), Store.lon(c), hereZone, subtitle(Store.lat(c), Store.lon(c), hereZone, utc))
            val hz = More.homeZone(c)
            val home = WindowSpec(More.homeCity(c), More.homeLat(c), More.homeLon(c), hz, subtitle(More.homeLat(c), More.homeLon(c), hz, utc))
            val d = diff(hereZone, hz, utc)
            for (id in ids) {
                val s = W.size(c, mgr, id, 250.0, 150.0)
                val rv = RemoteViews(c.packageName, R.layout.widget_two)
                rv.setImageViewBitmap(R.id.two_image, W.bitmap(c, s) { twoWindowWidget(s.w, s.h, here, home, utc, d) })
                rv.setString(R.id.clock_here, "setTimeZone", hereZone)
                rv.setString(R.id.clock_home, "setTimeZone", hz)
                rv.setOnClickPendingIntent(R.id.two_image, W.openApp(c))
                mgr.updateAppWidget(id, rv)
            }
            W.wakeAt(c, TwoWindowWidget::class.java, utc + 20 * 60_000L, 31)
        }
    }
}

// ---------------------------------------------------------------------
class ProverbWidget : AsyncWidget() {
    override fun work(c: Context, mgr: AppWidgetManager, ids: IntArray) = draw(c, mgr, ids)

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == NEXT) {
            More.nextProverb(context)
            val p = goAsync()
            Thread { try { draw(context, AppWidgetManager.getInstance(context), W.ids(context, ProverbWidget::class.java)) } finally { p.finish() } }.start()
        } else super.onReceive(context, intent)
    }

    companion object {
        const val NEXT = "com.rangmausam.NEXT_PROVERB"
        fun today(c: Context): Proverb = Proverbs.pick(More.proverbLangs(c), LocalDate.now().toEpochDay(), More.proverbOffset(c))
        fun draw(c: Context, mgr: AppWidgetManager, ids: IntArray) {
            val p = today(c)
            for (id in ids) {
                val s = W.size(c, mgr, id, 250.0, 110.0)
                val rv = RemoteViews(c.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.widget_image, W.bitmap(c, s) { proverbWidget(s.w, s.h, p) })
                rv.setContentDescription(R.id.widget_image, "${p.roman}. ${p.literal} ${p.sense}")
                rv.setOnClickPendingIntent(R.id.widget_image, W.self(c, ProverbWidget::class.java, NEXT, 41))
                mgr.updateAppWidget(id, rv)
            }
            // a fresh proverb just after midnight
            val midnight = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            W.wakeAt(c, ProverbWidget::class.java, midnight + 60_000, 42)
        }
    }
}
