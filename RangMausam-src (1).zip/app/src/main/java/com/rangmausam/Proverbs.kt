package com.rangmausam

/** A proverb with its own-script text, a romanisation, a literal gloss, the sense, and a motif for the leaf. */
data class Proverb(val lang: String, val text: String, val roman: String, val literal: String, val sense: String, val motif: String)

object Proverbs {
    val LANG_NAMES = mapOf("hi" to "Hindi", "ta" to "Tamil", "kn" to "Kannada", "bn" to "Bengali", "ml" to "Malayalam")

    val ALL = listOf(
        // Hindi
        Proverb("hi", "अधजल गगरी छलकत जाय", "Adhjal gagri chhalkat jaaye", "A half-full pot spills as it goes.", "Those who know little make the most noise.", "pot"),
        Proverb("hi", "बूँद-बूँद से घड़ा भरता है", "Boond-boond se ghada bharta hai", "Drop by drop, the pot fills.", "Small, steady efforts add up.", "drops"),
        Proverb("hi", "अब पछताए होत क्या, जब चिड़िया चुग गई खेत", "Ab pachhtaye hot kya, jab chidiya chug gayi khet", "What use is regret once the birds have eaten the field?", "Act in time; regret cannot undo neglect.", "bird"),
        Proverb("hi", "दूर के ढोल सुहावने", "Door ke dhol suhaavne", "Distant drums sound sweet.", "Things look better from far away.", "drum"),
        Proverb("hi", "नाच न जाने आँगन टेढ़ा", "Naach na jaane aangan tedha", "She can't dance, so she calls the courtyard crooked.", "Blaming circumstances for one's own lack of skill.", "bells"),
        Proverb("hi", "बंदर क्या जाने अदरक का स्वाद", "Bandar kya jaane adrak ka swaad", "What does a monkey know of the taste of ginger?", "Someone without taste cannot value something fine.", "ginger"),
        Proverb("hi", "आम के आम, गुठलियों के दाम", "Aam ke aam, guthliyon ke daam", "Mangoes to eat, and money for the stones too.", "A double gain from one thing.", "mango"),
        Proverb("hi", "जैसी करनी वैसी भरनी", "Jaisi karni vaisi bharni", "As you do, so you bear.", "Your actions come back to you.", "sprout"),
        // Tamil
        Proverb("ta", "சிறு துளி பெரு வெள்ளம்", "Siru thuli peru vellam", "Small drops make a great flood.", "Little by little becomes a lot.", "drops"),
        Proverb("ta", "ஆழம் தெரியாமல் காலை விடாதே", "Aazham theriyaamal kaalai vidaathe", "Don't put your foot in without knowing the depth.", "Understand a situation before stepping into it.", "ripples"),
        Proverb("ta", "கற்றது கைமண் அளவு, கல்லாதது உலகளவு", "Katrathu kaimman alavu, kallaathathu ulagalavu", "What we have learnt is a handful of sand; what we have not is the size of the world.", "Stay humble about how much you know.", "sand"),
        Proverb("ta", "யானைக்கும் அடி சறுக்கும்", "Yaanaikkum adi sarukkum", "Even an elephant's foot can slip.", "Even the most capable make mistakes.", "elephant"),
        Proverb("ta", "எறும்பு ஊரக் கல்லும் தேயும்", "Erumbu oorak kallum theyum", "Even stone wears away where ants keep crawling.", "Persistence wears down any obstacle.", "ants"),
        Proverb("ta", "அடி மேல் அடி வைத்தால் அம்மியும் நகரும்", "Adi mel adi vaiththaal ammiyum nagarum", "Push again and again, and even the grinding stone moves.", "Keep at it, and the immovable gives way.", "ammi"),
        Proverb("ta", "பசி வந்தால் பத்தும் பறந்து போகும்", "Pasi vandhaal paththum parandhu pogum", "When hunger comes, all ten virtues fly away.", "Need overrides good manners.", "meal"),
        Proverb("ta", "முயற்சி திருவினை ஆக்கும்", "Muyarchi thiruvinai aakkum", "Effort brings prosperity. (Thirukkural 616)", "Hard work makes its own fortune.", "sprout"),
        // Kannada
        Proverb("kn", "ಹನಿ ಹನಿ ಗೂಡಿದರೆ ಹಳ್ಳ, ತೆನೆ ತೆನೆ ಗೂಡಿದರೆ ಬಳ್ಳ", "Hani hani goodidare halla, tene tene goodidare balla", "Drop by drop a stream; ear by ear a measure of grain.", "Small things gathered become plenty.", "sheaf"),
        Proverb("kn", "ಕೈ ಕೆಸರಾದರೆ ಬಾಯಿ ಮೊಸರು", "Kai kesaraadare baayi mosaru", "Muddy hands, curd in the mouth.", "Hard work brings its reward.", "pot"),
        Proverb("kn", "ಹಿತ್ತಲ ಗಿಡ ಮದ್ದಲ್ಲ", "Hittala gida maddalla", "The plant in your own backyard is not medicine.", "We undervalue what is close at hand.", "plant"),
        Proverb("kn", "ಮಾಡಿದ್ದುಣ್ಣೋ ಮಹರಾಯ", "Maadiddunno maharaaya", "You eat what you cooked, my lord.", "You live with the results of your own actions.", "meal"),
        Proverb("kn", "ಅತಿ ಆಸೆ ಗತಿಗೇಡು", "Ati aase gatigedu", "Too much greed leads to ruin.", "Know when enough is enough.", "mango"),
        Proverb("kn", "ಕುಣಿಯಲಾರದವಳು ನೆಲ ಡೊಂಕು ಅಂದಳಂತೆ", "Kuniyalaaradavalu nela donku andalante", "She who couldn't dance said the floor was crooked.", "Blaming circumstances for one's own lack of skill.", "bells"),
        // Bengali
        Proverb("bn", "যত গর্জে তত বর্ষে না", "Joto gorje toto borshe na", "The more it thunders, the less it rains.", "Loud talk rarely comes with action.", "cloud"),
        Proverb("bn", "অল্প বিদ্যা ভয়ংকরী", "Olpo bidya bhoyonkori", "A little learning is dangerous.", "Half-knowledge misleads.", "lamp"),
        Proverb("bn", "ধান ভানতে শিবের গীত", "Dhan bhante shiber geet", "Singing Shiva's songs while husking paddy.", "Wandering off on a tangent from the task at hand.", "sheaf"),
        Proverb("bn", "এক মাঘে শীত যায় না", "Ek maaghe sheet jaay na", "One month of Magh does not end the winter.", "Hard times can come round again.", "flake"),
        Proverb("bn", "নাচতে না জানলে উঠোন বাঁকা", "Naachte na jaanle uthon baanka", "If you can't dance, the courtyard is crooked.", "Blaming circumstances for one's own lack of skill.", "bells"),
        Proverb("bn", "যেমন কর্ম তেমন ফল", "Jemon kormo temon phol", "As the deed, so the fruit.", "Actions bring matching results.", "mango"),
        // Malayalam
        Proverb("ml", "മുറ്റത്തെ മുല്ലയ്ക്ക് മണമില്ല", "Muttathe mullaykku manamilla", "The jasmine in your own courtyard has no scent.", "We overlook what is close to home.", "jasmine"),
        Proverb("ml", "അണ്ണാൻ കുഞ്ഞും തന്നാലായത്", "Annaan kunjum thannaalaayathu", "Even the little squirrel did what it could.", "Every contribution counts, however small.", "squirrel"),
        Proverb("ml", "കാക്കയ്ക്കും തൻകുഞ്ഞ് പൊൻകുഞ്ഞ്", "Kaakkaykkum thankunju ponkunju", "Even to the crow, its own chick is golden.", "Everyone treasures their own.", "crow"),
        Proverb("ml", "ആന കൊടുത്താലും ആശ കൊടുക്കരുത്", "Aana koduthaalum aasha kodukkaruthu", "Give away an elephant if you must, but never false hope.", "Don't make promises you can't keep.", "elephant"),
        Proverb("ml", "ചൊട്ടയിലെ ശീലം ചുടല വരെ", "Chottayile sheelam chudala vare", "Habits from the cradle last to the cremation ground.", "Childhood habits last a lifetime.", "sprout"),
    )

    /** Today's proverb from the chosen languages; [offset] moves forward when the widget is tapped. */
    fun pick(langs: Set<String>, epochDay: Long, offset: Int): Proverb {
        val pool = ALL.filter { it.lang in langs }.ifEmpty { ALL }
        // stride by a number coprime with the pool size, so consecutive days hop between languages
        val stride = listOf(7, 11, 13, 5, 3, 1).first { pool.size % it != 0 || it == 1 }
        val i = (((epochDay + offset) * stride) % pool.size + pool.size) % pool.size
        return pool[i.toInt()]
    }
}
