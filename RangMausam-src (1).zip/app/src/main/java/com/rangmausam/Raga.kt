package com.rangmausam

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The time theory of Hindustani ragas (samay chakra), as twelve two-hour slots.
 * Assignments follow the commonly taught tradition; schools differ by an hour or so at the edges.
 * carnatic = a closely related Carnatic raga, given only where the kinship is well established.
 */
data class Raga(val name: String, val deva: String, val start: Int, val period: String, val mood: String,
                val thaat: String, val carnatic: String?, val motif: String, val skyTop: String, val skyLow: String, val ground: String)

object Ragas {
    val ALL = listOf(
        Raga("Lalit", "ललित", 4, "Before dawn", "Longing, the night giving way", "Marwa", null, "lalit", "#2B2F5E", "#C8607A", "#3A2E4A"),
        Raga("Bhairav", "भैरव", 6, "Dawn", "Serene, devotional, grave", "Bhairav", "Mayamalavagowla", "bhairav", "#E9A27A", "#F8D9A0", "#6B4A3A"),
        Raga("Todi", "तोड़ी", 8, "Morning", "Tender, a gentle ache", "Todi", "Shubhapantuvarali", "todi", "#8CC7DE", "#E7F1D8", "#5E7A3E"),
        Raga("Asavari", "आसावरी", 10, "Late morning", "Renunciation, quiet sorrow", "Asavari", null, "asavari", "#76B9DA", "#DCEFF2", "#7A6A3A"),
        Raga("Brindavani Sarang", "बृंदावनी सारंग", 12, "Midday", "Bright, the stillness of noon", "Kafi", "Brindavana Saranga", "sarang", "#F3D98A", "#FFF3C8", "#4F7A5E"),
        Raga("Bhimpalasi", "भीमपलासी", 14, "Afternoon", "Longing for someone far away", "Kafi", "Abheri", "bhimpalasi", "#F2C14E", "#FBE6B0", "#8A6A2E"),
        Raga("Multani", "मुलतानी", 16, "Late afternoon", "Intense, inward, long shadows", "Todi", null, "multani", "#E8913A", "#F8CF8A", "#7A4A24"),
        Raga("Marwa", "मारवा", 18, "Sunset", "Restless, the day slipping away", "Marwa", null, "marwa", "#C8503A", "#F2A35A", "#4A2A24"),
        Raga("Yaman", "यमन", 20, "Evening", "Peace, devotion, quiet romance", "Kalyan", "Kalyani", "yaman", "#3B3F7A", "#7A5A8E", "#2A2440"),
        Raga("Bihag", "बिहाग", 22, "Late evening", "Joyful, romantic, moonlit", "Bilawal", "Bihag", "bihag", "#26306A", "#4A5A9A", "#1E2440"),
        Raga("Darbari Kanada", "दरबारी कान्हड़ा", 0, "Midnight", "Grave, majestic, profound", "Asavari", null, "darbari", "#141B3D", "#2A3466", "#141830"),
        Raga("Malkauns", "मालकौंस", 2, "Deep night", "Meditative, still, serious", "Bhairavi", "Hindolam", "malkauns", "#0E1430", "#22305E", "#0E1226"),
    )

    fun at(hour: Int): Raga {
        val slotStart = (hour / 2) * 2
        return ALL.first { it.start == slotStart }
    }
    fun next(r: Raga): Raga = ALL.first { it.start == (r.start + 2) % 24 }
    fun hourLabel(h: Int) = when { h == 0 -> "midnight"; h == 12 -> "noon"; h < 12 -> "$h am"; else -> "${h - 12} pm" }
    fun window(r: Raga) = "${hourLabel(r.start)} to ${hourLabel((r.start + 2) % 24)}"
    fun searchUrl(r: Raga) = "https://www.youtube.com/results?search_query=" + ("raga " + r.name + " hindustani").replace(" ", "+")
}

// ---------------- painting ----------------

/** A small ragamala-style miniature for [r], painted in a w x h box. [frac] = how far through the slot (moves sun or moon). */
fun Ink.ragaPainting(r: Raga, w: Double, h: Double, frac: Double) {
    val m = 7.0
    // red outer border, yellow inner rule, dotted rule (as on Rajasthani ragamala folios)
    fill("M 0 0 L $w 0 L $w $h L 0 $h Z", "#A3261C")
    fill("M ${m - 2} ${m - 2} L ${w - m + 2} ${m - 2} L ${w - m + 2} ${h - m + 2} L ${m - 2} ${h - m + 2} Z", "#E9B949")
    val x0 = m; val y0 = m; val iw = w - 2 * m; val ih = h - 2 * m
    // sky in three flat bands
    val sky = ih * 0.72
    fill("M $x0 $y0 L ${x0 + iw} $y0 L ${x0 + iw} ${y0 + sky} L $x0 ${y0 + sky} Z", r.skyTop)
    fill("M $x0 ${y0 + sky * 0.62} L ${x0 + iw} ${y0 + sky * 0.62} L ${x0 + iw} ${y0 + sky} L $x0 ${y0 + sky} Z", r.skyLow)
    line("M $x0 ${y0 + sky * 0.62} L ${x0 + iw} ${y0 + sky * 0.62}", ca("#FFFFFF", 0.25), 0.8)
    val night = r.start >= 20 || r.start < 4
    val R = Ink.Rng(r.start + 3)
    if (night || r.start == 4) for (i in 0 until 14) { val sx = x0 + iw * (0.05 + R.next() * 0.9); val sy = y0 + sky * (0.05 + R.next() * 0.45); sparkle(sx, sy, 1.2 + R.next() * 1.8, "#F5E6A8") }
    // sun or moon travelling across the slot
    val arcX = x0 + iw * (0.15 + 0.7 * frac); val arcY = y0 + sky * (0.42 - sin(frac * PI) * 0.22)
    val orb = min(iw, ih) * 0.075
    if (night || r.start == 4) crescent(arcX, arcY, orb, r.skyTop)
    else if (r.start == 12) folkSun(arcX, arcY, orb * 1.1, true)
    else { dot(arcX, arcY, orb * 1.6, ca("#FFF4D0", 0.35)); shape(ellD(arcX, arcY, orb, orb), "#F6A21B", Art.INK, 1.0) }
    // rolling hills
    val gy = y0 + sky
    fill("M $x0 $gy Q ${x0 + iw * 0.25} ${gy - ih * 0.12} ${x0 + iw * 0.5} ${gy - ih * 0.02} Q ${x0 + iw * 0.75} ${gy - ih * 0.14} ${x0 + iw} ${gy - ih * 0.03} L ${x0 + iw} $gy Z", ca(r.ground, 0.65))
    fill("M $x0 $gy L ${x0 + iw} $gy L ${x0 + iw} ${y0 + ih} L $x0 ${y0 + ih} Z", r.ground)
    for (i in 0 until 9) { val fx = x0 + iw * (0.06 + i * 0.11); dot(fx, gy + ih * 0.16, 1.2, ca("#F5E6A8", 0.6)) }
    // the raga's own motif
    val s = min(iw * 0.62, ih * 0.62) / 100
    push(x0 + iw / 2, gy - 4, s); push(-50.0, -88.0); ragaMotif(r.motif); pop(); pop()
    line("M $x0 $y0 L ${x0 + iw} $y0 L ${x0 + iw} ${y0 + ih} L $x0 ${y0 + ih} Z", Art.INK, 1.2)
}

/** Motifs drawn in a 100 x 100 box standing on y = 88. */
fun Ink.ragaMotif(k: String) {
    val I = Art.INK
    when (k) {
        "lalit" -> { // lotus buds opening at first light
            for (dx in listOf(-22.0, 0.0, 22.0)) {
                line("M ${50 + dx} 88 Q ${50 + dx * 1.2} 70 ${50 + dx} 56", "#3E6B3A", 2.2)
                shape("M ${50 + dx} 40 Q ${58 + dx} 50 ${50 + dx} 58 Q ${42 + dx} 50 ${50 + dx} 40 Z", if (dx == 0.0) "#F2A7B8" else "#E2577F", I, 1.2)
            }
            shape(ellD(30.0, 86.0, 16.0, 4.0), "#3E6B3A", I, 1.0); shape(ellD(70.0, 86.0, 14.0, 3.5), "#3E6B3A", I, 1.0)
        }
        "bhairav" -> { // temple shikhara at dawn
            shape("M 30 88 L 70 88 L 70 82 L 30 82 Z", "#C88A4A", I, 1.4)
            shape("M 34 82 L 34 58 Q 36 30 50 14 Q 64 30 66 58 L 66 82 Z", "#E9C46A", I, 1.6)
            for (y in listOf(62.0, 50.0, 38.0)) line("M ${36 + (62 - y) * 0.1} $y L ${64 - (62 - y) * 0.1} $y", "#B5822C", 1.2)
            shape(ellD(50.0, 13.0, 7.0, 2.5), "#C88A4A", I, 1.2)
            line("M 50 11 L 50 0", I, 1.2); shape("M 50 0 L 60 3 L 50 6 Z", "#D2382A", I, 0.8)
            shape("M 45 82 L 45 70 Q 50 64 55 70 L 55 82 Z", "#2A1A14", I, 1.0)
        }
        "todi" -> { // a chital deer listening (the Todi ragini charms deer with her veena)
            shape("M 28 58 Q 30 46 50 46 Q 70 46 72 56 Q 74 66 60 68 L 36 68 Q 26 66 28 58 Z", "#C8783A", I, 1.4)
            for (p in listOf(36.0 to 54.0, 46.0 to 52.0, 56.0 to 54.0, 64.0 to 58.0, 42.0 to 60.0, 52.0 to 61.0)) dot(p.first, p.second, 1.3, "#FFF4DE")
            shape("M 66 50 L 72 34 L 78 34 L 76 50 Z", "#C8783A", I, 1.2)
            shape("M 72 34 Q 74 24 84 26 Q 88 30 80 36 Z", "#C8783A", I, 1.2)
            dot(80.0, 29.0, 1.0, I)
            line("M 74 26 L 70 12 M 71 16 L 64 12 M 78 25 L 82 10 M 81 15 L 88 12", I, 1.4)
            for (x in listOf(36.0, 42.0, 58.0, 64.0)) line("M $x 67 L ${x + (if (x < 50) -2 else 2)} 88", I, 2.0)
            line("M 28 56 Q 22 54 24 50", I, 1.4)
        }
        "asavari" -> { // snakes on a sandalwood hill (Asavari ragini)
            shape("M 14 88 Q 30 50 50 48 Q 70 50 86 88 Z", "#7A8A4A", I, 1.4)
            line("M 50 48 L 50 22", "#5A3A1E", 3.0)
            for (a in listOf(-40.0, -10.0, 20.0)) { val r = a * PI / 180; shape(ellD(50 + sin(r) * 14, 18 - cos(r) * 6, 12.0, 7.0), "#3E6B3A", I, 1.0) }
            line("M 30 80 C 36 70 26 64 34 56 C 40 50 46 56 44 62", "#2F5A3A", 3.2)
            line("M 30 80 C 36 70 26 64 34 56 C 40 50 46 56 44 62", "#E9C46A", 1.0)
            dot(44.0, 62.0, 2.6, "#2F5A3A")
            line("M 66 84 C 60 76 72 70 64 64", "#2F5A3A", 3.0); dot(64.0, 64.0, 2.4, "#2F5A3A")
        }
        "sarang" -> { // lotus pond under the noon sun
            fill("M 4 72 Q 50 64 96 72 L 96 90 L 4 90 Z", "#3E8EAE")
            for (y in listOf(76.0, 82.0)) line("M 10 $y Q 20 ${y - 2} 30 $y Q 40 ${y + 2} 50 $y Q 60 ${y - 2} 70 $y Q 80 ${y + 2} 90 $y", "#BFE3F0", 1.2)
            for (x in listOf(26.0, 72.0)) shape(ellD(x, 74.0, 12.0, 3.5), "#4C7A34", I, 1.0)
            for (x in listOf(40.0, 58.0)) {
                for (a in listOf(-35.0, 0.0, 35.0)) { val r = a * PI / 180
                    shape("M $x 70 Q ${x - 7 + sin(r) * 10} ${60 - cos(r) * 4} ${x + sin(r) * 10} ${54 - cos(r) * 6} Q ${x + 7 + sin(r) * 10} ${60 - cos(r) * 4} $x 70 Z", "#F2A7B8", I, 1.0) }
            }
        }
        "bhimpalasi" -> { // two birds on a branch, a little apart
            line("M 10 70 Q 50 60 90 66", "#5A3A1E", 3.0)
            for (x in listOf(24.0, 30.0, 70.0)) shape(ellD(x, 66.0 - (x - 50) * 0.02, 4.0, 2.0), "#4C7A34", I, 0.8)
            for ((bx, dir) in listOf(34.0 to 1.0, 66.0 to -1.0)) {
                shape("M ${bx - 8 * dir} 56 Q $bx 48 ${bx + 8 * dir} 54 Q ${bx + 12 * dir} 50 ${bx + 14 * dir} 52 Q ${bx + 10 * dir} 56 ${bx + 8 * dir} 58 Q $bx 64 ${bx - 10 * dir} 60 Z", "#1F6E8C", I, 1.2)
                shape("M ${bx - 2 * dir} 55 Q ${bx - 6 * dir} 48 ${bx - 12 * dir} 52 Z", "#F2C14E", I, 0.8)
                dot(bx + 10 * dir, 52.5, 0.9, I)
                line("M ${bx + 14 * dir} 52 L ${bx + 18 * dir} 53", "#E8913A", 1.4)
            }
        }
        "multani" -> { // a palm with a long late-afternoon shadow
            fill("M 46 88 L 96 82 L 96 88 Z", ca("#2A1A14", 0.35))
            line("M 46 88 Q 42 60 50 26", "#7A4A24", 4.0)
            for (k2 in 0 until 7) { val a = (-150 + k2 * 25) * PI / 180
                line("M 50 26 Q ${50 + cos(a) * 14} ${26 + sin(a) * 14 - 6} ${50 + cos(a) * 26} ${26 + sin(a) * 26 + 6}", "#3E6B3A", 2.6) }
            for (p in listOf(46.0, 52.0)) dot(p, 30.0, 2.2, "#7A4A24")
        }
        "marwa" -> { // birds flying home at sunset
            for ((x, y, sc) in listOf(Triple(30.0, 30.0, 1.0), Triple(48.0, 22.0, 0.8), Triple(62.0, 36.0, 1.1), Triple(76.0, 26.0, 0.7), Triple(40.0, 44.0, 0.6)))
                line("M ${x - 8 * sc} ${y - 3 * sc} Q ${x - 4 * sc} ${y - 6 * sc} $x $y Q ${x + 4 * sc} ${y - 6 * sc} ${x + 8 * sc} ${y - 3 * sc}", "#2A1A14", 1.8)
            shape("M 20 88 L 24 74 L 36 74 L 40 88 Z", "#4A2A24", I, 1.0); shape("M 18 74 L 30 64 L 42 74 Z", "#7A3A24", I, 1.0)
            shape("M 62 88 L 66 76 L 76 76 L 80 88 Z", "#4A2A24", I, 1.0); shape("M 60 76 L 71 68 L 82 76 Z", "#7A3A24", I, 1.0)
            dot(30.0, 81.0, 1.6, "#F6C76A")
        }
        "yaman" -> { // tulsi planter with the evening lamp
            shape("M 34 88 L 36 60 L 64 60 L 66 88 Z", "#E9C46A", I, 1.6)
            shape("M 30 60 L 70 60 L 68 54 L 32 54 Z", "#C88A4A", I, 1.4)
            shape("M 44 84 L 44 72 Q 50 66 56 72 L 56 84 Z", "#3A2418", I, 1.0)
            dot(50.0, 80.0, 2.0, "#F6A21B"); dot(50.0, 76.0, 3.2, ca("#F5C542", 0.35))
            line("M 50 54 L 50 26", "#3E6B3A", 2.2)
            for (y in listOf(30.0, 38.0, 46.0)) { shape(ellD(44.0, y, 6.0, 2.6), "#4C9A3C", I, 0.8); shape(ellD(56.0, y + 3, 6.0, 2.6), "#4C9A3C", I, 0.8) }
            sparkle(76.0, 20.0, 4.0, "#F5E6A8")
        }
        "bihag" -> { // jasmine creeper under a rising moon
            line("M 20 88 Q 24 60 40 50 Q 56 40 62 20", "#3E6B3A", 2.2)
            line("M 40 50 Q 60 54 76 44", "#3E6B3A", 1.8)
            for (p in listOf(30.0 to 66.0, 38.0 to 52.0, 50.0 to 44.0, 58.0 to 30.0, 62.0 to 50.0, 74.0 to 45.0, 24.0 to 78.0))
                for (a in 0 until 5) { val an = a / 5.0 * PI * 2; dot(p.first + cos(an) * 2.4, p.second + sin(an) * 2.4, 1.6, "#FFFDF6") }
            for (p in listOf(34.0 to 58.0, 46.0 to 48.0, 68.0 to 47.0)) shape(ellD(p.first, p.second, 4.0, 1.8), "#4C9A3C", I, 0.6)
        }
        "darbari" -> { // a domed chhatri pavilion, the royal court at midnight
            shape("M 20 88 L 80 88 L 78 82 L 22 82 Z", "#C8B48A", I, 1.4)
            for (x in listOf(28.0, 44.0, 56.0, 72.0)) shape("M ${x - 2} 82 L ${x - 2} 56 L ${x + 2} 56 L ${x + 2} 82 Z", "#E8DCC0", I, 1.0)
            shape("M 22 56 L 78 56 L 74 50 L 26 50 Z", "#C8B48A", I, 1.2)
            shape("M 30 50 Q 30 26 50 22 Q 70 26 70 50 Z", "#E8DCC0", I, 1.4)
            line("M 50 22 L 50 10", I, 1.2); dot(50.0, 10.0, 2.2, "#E9B949")
            for (x in listOf(36.0, 50.0, 64.0)) shape("M ${x - 4} 82 L ${x - 4} 66 Q $x 60 ${x + 4} 66 L ${x + 4} 82 Z", ca("#F6C76A", 0.5), I, 0.6)
        }
        "malkauns" -> { // a still lake holding the moon
            fill("M 4 66 Q 50 60 96 66 L 96 90 L 4 90 Z", "#22305E")
            for ((y, w2) in listOf(70.0 to 10.0, 75.0 to 7.0, 80.0 to 5.0, 85.0 to 3.0)) line("M ${62 - w2} $y L ${62 + w2} $y", "#F2E6B8", 1.4)
            shape("M 12 66 L 20 50 L 28 66 Z", "#141830", I, 0.8); shape("M 24 66 L 34 44 L 44 66 Z", "#141830", I, 0.8)
            shape(ellD(78.0, 64.0, 6.0, 1.6), "#2F5A3A", I, 0.6)
        }
    }
}

/** Small tanpura glyph, 100 box. */
fun Ink.tanpura(c: String) {
    shape(ellD(50.0, 78.0, 18.0, 18.0), c, Art.INK, 1.6)
    shape("M 46 62 L 54 62 L 53 6 L 47 6 Z", c, Art.INK, 1.4)
    for (y in listOf(10.0, 18.0, 26.0)) { line("M 47 $y L 41 ${y - 2}", Art.INK, 1.6); line("M 53 $y L 59 ${y - 2}", Art.INK, 1.6) }
    for (x in listOf(48.5, 50.0, 51.5)) line("M $x 8 L $x 88", "#FFF4DE", 0.5)
    ring(50.0, 78.0, 9.0, "#A3261C", 1.4)
}
