package com.rangmausam

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Settings screen: place, script, units, and a gallery of every weather state. */
class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var cityBox: EditText
    private val paper = Color.parseColor("#F6EBD3")
    private val ink = Color.parseColor("#2A1A14")
    private val sindoor = Color.parseColor("#B8291A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(40)); setBackgroundColor(paper) }
        val scroll = ScrollView(this).apply { setBackgroundColor(paper); addView(root) }
        setContentView(scroll)

        root.addView(TextView(this).apply { text = "Rang Mausam"; textSize = 30f; setTextColor(ink); typeface = Store.fonts(this@MainActivity).serif })
        root.addView(label("Weather as a carry-list, in folk colours. Long-press your home screen, choose Widgets, and add Rang Mausam."))

        preview = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(16), 0, dp(8)) }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        status = label("")
        root.addView(status)

        root.addView(heading("Place"))
        root.addView(button("Use my location") { askLocation() })
        val cityRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cityBox = EditText(this).apply { hint = "Or type a city, e.g. Chamarajanagar"; setSingleLine(true); setTextColor(ink) }
        cityRow.addView(cityBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cityRow.addView(button("Set") { setCity(cityBox.text.toString().trim()) })
        root.addView(cityRow)

        root.addView(heading("Script for the weather word"))
        val langs = listOf("hi" to "हिंदी", "kn" to "ಕನ್ನಡ", "ta" to "தமிழ்", "bn" to "বাংলা")
        root.addView(row(langs.map { (code, name) -> name to { Store.setLang(this, code); changed() } }))

        root.addView(heading("Units"))
        root.addView(row(listOf("°C" to { Store.setFahrenheit(this, false); changed() }, "°F" to { Store.setFahrenheit(this, true); changed() })))

        root.addView(button("Refresh widget now") { changed() })

        root.addView(heading("Every weather state"))
        root.addView(label("What the widget shows for each kind of weather. Rain, snow and storms count if they are expected in the next 12 hours."))
        val fonts = Store.fonts(this)
        val scale = resources.displayMetrics.widthPixels / 380f
        for (k in Art.KEYS) {
            val iv = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(10), 0, 0); contentDescription = Art.LABELS[k] }
            iv.setImageBitmap(Art.render("medium", Weather.demo(k), Store.lang(this), fonts, scale))
            root.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(label("Forecast data: Open-Meteo.com (CC BY 4.0). Fonts: Playfair Display and Lora (SIL Open Font License)."))

        if (Store.forecast(this) == null && !Store.hasLocationPermission(this)) askLocation() else loadPreview(network = Store.forecast(this) == null)
    }

    private fun heading(t: String) = TextView(this).apply { text = t; textSize = 17f; setTextColor(sindoor); setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(22), 0, dp(6)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setTextColor(ink); setPadding(0, dp(4), 0, dp(4)) }
    private fun button(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }
    private fun row(items: List<Pair<String, () -> Unit>>) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for ((t, f) in items) addView(button(t, f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun changed() { loadPreview(network = true); RangWidget.updateAll(this) }

    private fun loadPreview(network: Boolean) {
        status.text = if (network) "Fetching the forecast…" else ""
        Thread {
            val m = RangWidget.currentModel(this, network)
            val bmp = Art.render("medium", m, Store.lang(this), Store.fonts(this), resources.displayMetrics.widthPixels / 380f)
            runOnUiThread {
                preview.setImageBitmap(bmp)
                status.text = "Showing ${m.place}. Tap Refresh after changing settings."
            }
        }.start()
    }

    private fun setCity(name: String) {
        if (name.isEmpty()) return
        status.text = "Looking up $name…"
        Thread {
            val r = try { Weather.geocode(name) } catch (e: Exception) { null }
            runOnUiThread {
                if (r == null) status.text = "Could not find \"$name\". Try a nearby town or check your connection."
                else { Store.saveLocation(this, r.first, r.second, r.third, "city"); changed() }
            }
        }.start()
    }

    private fun askLocation() {
        if (Store.hasLocationPermission(this)) { fetchFix(); return }
        requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) fetchFix()
        else { status.text = "No location permission. Type a city instead."; loadPreview(network = true) }
    }

    /** Gets a fresh fix while the app is open, so the widget has a place even in the background. */
    private fun fetchFix() {
        status.text = "Finding you…"
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val save: (android.location.Location?) -> Unit = { loc ->
            val l = loc ?: Store.lastFix(this)
            if (l == null) runOnUiThread { status.text = "Could not get a location fix. Type a city instead." }
            else Thread {
                val name = Store.placeName(this, l.latitude, l.longitude) ?: "Your location"
                Store.saveLocation(this, l.latitude, l.longitude, name, "gps")
                runOnUiThread { changed() }
            }.start()
        }
        try {
            if (Build.VERSION.SDK_INT >= 30 && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { save(it) }
            } else save(null)
        } catch (e: SecurityException) { save(null) }
    }

    override fun onResume() { super.onResume(); window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR }
}
