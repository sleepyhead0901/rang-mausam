package com.rangmausam

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ============================================================
// RANG MAUSAM : drawing core (Android port of the Scriptable core)
// Every object is drawn in a 100 x 100 local box with ink outlines.
// ============================================================

data class Theme(val bg: String, val panel: String, val text: String, val sub: String, val accent: String,
                 val border: String, val dots: String, val grain: String)

data class Day(val dow: Int, val key: String, val hi: Double, val lo: Double)

data class Model(val key: String, val night: Boolean, val temp: Double, val feels: Double, val hi: Double, val lo: Double,
                 val place: String, val time: String, val advice: String, val daily: List<Day>)

class Fonts(val serif: Typeface, val italic: Typeface, val sansBold: Typeface, val indic: Typeface)

object Art {
    const val INK = "#2A1A14"

    val THEMES = mapOf(
        "sunny" to Theme("#F2A31B", "#FCEBC6", "#2A1A14", "#7A2A12", "#B8291A", "#FCEBC6", "#B8291A", "#7A2A12"),
        "hot" to Theme("#C8321F", "#F9D9A0", "#FFF4DE", "#FFD27A", "#FFD27A", "#FFD27A", "#FFD27A", "#3B0A05"),
        "cloudy" to Theme("#3F6E9E", "#E6ECEE", "#FFF8EA", "#F6C76A", "#F6C76A", "#E6ECEE", "#F6C76A", "#10233D"),
        "rain" to Theme("#2E5B3E", "#D5E5C4", "#FFF8EA", "#F2C14E", "#F2C14E", "#D5E5C4", "#EE7FA0", "#0E2416"),
        "storm" to Theme("#1B2450", "#34457F", "#FFF8EA", "#F5B82E", "#F5B82E", "#8FA0D8", "#F5B82E", "#000000"),
        "snow" to Theme("#F4EFE4", "#FFFFFF", "#1F4E9C", "#C2185B", "#1F4E9C", "#1F4E9C", "#1F4E9C", "#1F4E9C"),
        "fog" to Theme("#8FA392", "#E4E8DA", "#1E2B22", "#5A2A35", "#5A2A35", "#E4E8DA", "#5A2A35", "#1E2B22"),
        "cold" to Theme("#6E1E22", "#F2D48A", "#FBEBC8", "#F2B544", "#F2B544", "#F2B544", "#F2B544", "#000000"),
        "windy" to Theme("#147B78", "#F7E7C6", "#FFF8EA", "#F6B93B", "#F6B93B", "#F7E7C6", "#F06D4F", "#05302F"),
        "night" to Theme("#16224A", "#26366E", "#FFF4E0", "#F2A7B8", "#F2A7B8", "#F2A7B8", "#F5C542", "#000000"),
    )
    val KEYS = THEMES.keys.toList()

    val WORDS = mapOf(
        "hi" to mapOf("sunny" to "धूप", "hot" to "लू", "cloudy" to "बादल", "rain" to "बारिश", "storm" to "तूफ़ान", "snow" to "बर्फ़", "fog" to "कोहरा", "cold" to "ठंड", "windy" to "हवा", "night" to "चाँदनी"),
        "kn" to mapOf("sunny" to "ಬಿಸಿಲು", "hot" to "ಬಿರುಬಿಸಿಲು", "cloudy" to "ಮೋಡ", "rain" to "ಮಳೆ", "storm" to "ಗುಡುಗು ಮಳೆ", "snow" to "ಹಿಮ", "fog" to "ಮಂಜು", "cold" to "ಚಳಿ", "windy" to "ಗಾಳಿ", "night" to "ಬೆಳದಿಂಗಳು"),
        "ta" to mapOf("sunny" to "வெயில்", "hot" to "கடும் வெயில்", "cloudy" to "மேகம்", "rain" to "மழை", "storm" to "இடி மழை", "snow" to "பனி", "fog" to "மூடுபனி", "cold" to "குளிர்", "windy" to "காற்று", "night" to "நிலவு"),
        "bn" to mapOf("sunny" to "রোদ", "hot" to "প্রখর রোদ", "cloudy" to "মেঘলা", "rain" to "বৃষ্টি", "storm" to "ঝড়", "snow" to "তুষার", "fog" to "কুয়াশা", "cold" to "শীত", "windy" to "হাওয়া", "night" to "জ্যোৎস্না"),
    )
    val DAYS = mapOf(
        "en" to listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"),
        "hi" to listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"),
        "kn" to listOf("ಭಾನು", "ಸೋಮ", "ಮಂಗಳ", "ಬುಧ", "ಗುರು", "ಶುಕ್ರ", "ಶನಿ"),
        "ta" to listOf("ஞாயிறு", "திங்கள்", "செவ்வாய்", "புதன்", "வியாழன்", "வெள்ளி", "சனி"),
        "bn" to listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহস্পতি", "শুক্র", "শনি"),
    )
    val LABELS = mapOf("sunny" to "SUNSHINE", "hot" to "SCORCHING", "cloudy" to "CLOUDY", "rain" to "RAIN", "storm" to "THUNDERSTORM",
        "snow" to "SNOW", "fog" to "FOG", "cold" to "COLD", "windy" to "WINDY", "night" to "CLEAR NIGHT")
    val ADVICE = mapOf(
        "sunny" to "Hat and shades. Sip water.",
        "hot" to "Fill the matka. Stay in the shade.",
        "cloudy" to "Kurta weather. Jhola on the shoulder.",
        "rain" to "Chhata and raincoat today.",
        "storm" to "Stay in. Chai and pakoras.",
        "snow" to "Boots on. Jacket zipped.",
        "fog" to "Monkey cap and muffler.",
        "cold" to "Shawl on. Chai in hand.",
        "windy" to "Kite weather. Hold the dupatta.",
        "night" to "Clear night. Light a diya.",
    )
    fun soon(key: String, s: String): String? = when (key) {
        "rain" -> "Rain by $s. Carry the chhata."
        "storm" -> "Storm by $s. Stay in with chai."
        "snow" -> "Snow by $s. Boots on."
        else -> null
    }

    // logical sizes (dp-like units) for each layout
    val SIZES = mapOf("small" to Pair(158.0, 158.0), "medium" to Pair(338.0, 158.0), "large" to Pair(338.0, 354.0))

    /** Render a widget bitmap. scale = pixels per logical unit. */
    fun render(family: String, m: Model, lang: String, fonts: Fonts, scale: Float, corner: Float = 22f): Bitmap {
        val (w, h) = SIZES[family] ?: SIZES.getValue("medium")
        val bmp = Bitmap.createBitmap((w * scale).roundToInt(), (h * scale).roundToInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(0f, 0f, (w * scale).toFloat(), (h * scale).toFloat(), corner * scale, corner * scale, Path.Direction.CW)
        canvas.clipPath(clip)
        Ink(canvas, fonts, scale.toDouble()).widget(family, w, h, m, lang)
        return bmp
    }
}

private class Tf(val x: Double, val y: Double, val s: Double, val c: Double, val sn: Double)

class Ink(private val cv: Canvas, private val fonts: Fonts, baseScale: Double) {
    private val INK = Art.INK
    private val stack = ArrayList<Tf>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init { stack.add(Tf(0.0, 0.0, baseScale, 1.0, 0.0)) }

    // ---------- transforms ----------
    fun push(x: Double, y: Double, s: Double = 1.0, deg: Double = 0.0) {
        val t = stack.last(); val r = deg * PI / 180; val c = cos(r); val sn = sin(r)
        stack.add(Tf(t.x + t.s * (x * t.c - y * t.sn), t.y + t.s * (x * t.sn + y * t.c), t.s * s, t.c * c - t.sn * sn, t.sn * c + t.c * sn))
    }
    fun pop() { stack.removeAt(stack.size - 1) }
    private fun px(u: Double, v: Double): Float { val t = stack.last(); return (t.x + t.s * (u * t.c - v * t.sn)).toFloat() }
    private fun py(u: Double, v: Double): Float { val t = stack.last(); return (t.y + t.s * (u * t.sn + v * t.c)).toFloat() }
    private fun S(): Double = stack.last().s

    private val tokRe = Regex("[MLQCZ]|-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?")
    fun mk(d: String): Path {
        val p = Path(); val tk = tokRe.findAll(d.replace(',', ' ')).map { it.value }.toList()
        var i = 0; var cmd = "M"
        fun n(): Double = tk[i++].toDouble()
        while (i < tk.size) {
            if (tk[i].length == 1 && tk[i][0] in "MLQCZ") cmd = tk[i++]
            when (cmd) {
                "M" -> { val x = n(); val y = n(); p.moveTo(px(x, y), py(x, y)); cmd = "L" }
                "L" -> { val x = n(); val y = n(); p.lineTo(px(x, y), py(x, y)) }
                "Q" -> { val a = n(); val b = n(); val x = n(); val y = n(); p.quadTo(px(a, b), py(a, b), px(x, y), py(x, y)) }
                "C" -> { val a = n(); val b = n(); val c = n(); val e = n(); val x = n(); val y = n()
                    p.cubicTo(px(a, b), py(a, b), px(c, e), py(c, e), px(x, y), py(x, y)) }
                "Z" -> { p.close(); if (i < tk.size && !(tk[i].length == 1 && tk[i][0] in "MLQCZ")) i++ }
            }
        }
        return p
    }

    // ---------- colours ----------
    private fun col(c: Any): Int = when (c) {
        is Int -> c
        is String -> Color.parseColor(c)
        else -> Color.BLACK
    }
    fun ca(hex: String, a: Double): Int { val c = Color.parseColor(hex); return Color.argb((a * 255).roundToInt(), Color.red(c), Color.green(c), Color.blue(c)) }

    // ---------- primitives ----------
    fun fill(d: Any, c: Any) {
        paint.style = Paint.Style.FILL; paint.color = col(c)
        cv.drawPath(if (d is String) mk(d) else d as Path, paint)
    }
    fun line(d: Any, c: Any, w: Double = 2.0) {
        paint.style = Paint.Style.STROKE; paint.color = col(c)
        paint.strokeWidth = max(0.5, w * S()).toFloat()
        paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
        cv.drawPath(if (d is String) mk(d) else d as Path, paint)
    }
    fun shape(d: String, c: Any, ink: Any = INK, w: Double = 2.2) { val p = mk(d); fill(p, c); line(p, ink, w) }
    fun ellD(cx: Double, cy: Double, rx: Double, ry: Double): String {
        val k = 0.5523
        return "M ${cx + rx} $cy C ${cx + rx} ${cy + ry * k} ${cx + rx * k} ${cy + ry} $cx ${cy + ry} C ${cx - rx * k} ${cy + ry} ${cx - rx} ${cy + ry * k} ${cx - rx} $cy C ${cx - rx} ${cy - ry * k} ${cx - rx * k} ${cy - ry} $cx ${cy - ry} C ${cx + rx * k} ${cy - ry} ${cx + rx} ${cy - ry * k} ${cx + rx} $cy Z"
    }
    fun dot(cx: Double, cy: Double, r: Double, c: Any) = fill(ellD(cx, cy, r, r), c)
    fun ring(cx: Double, cy: Double, r: Double, c: Any, w: Double) = line(ellD(cx, cy, r, r), c, w)
    private fun q(p0: DoubleArray, c: DoubleArray, p1: DoubleArray, t: Double): DoubleArray {
        val u = 1 - t
        return doubleArrayOf(u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1])
    }
    private fun incl(a: Double, b: Double, st: Double) = generateSequence(a) { it + st }.takeWhile { it <= b + 1e-9 }
    private fun excl(a: Double, b: Double, st: Double) = generateSequence(a) { it + st }.takeWhile { it < b - 1e-9 }

    class Rng(private var seed: Int) {
        fun next(): Double {
            seed += 0x6D2B79F5
            var t = seed
            t = (t xor (t ushr 15)) * (1 or t)
            t = (t + ((t xor (t ushr 7)) * (61 or t))) xor t
            return ((t xor (t ushr 14)).toLong() and 0xffffffffL).toDouble() / 4294967296.0
        }
    }

    enum class Align { LEFT, CENTER, RIGHT }
    /** Text drawn top-aligned in a box, wrapping on spaces, like Scriptable's drawTextInRect. */
    fun text(str: String, x: Double, y: Double, w: Double, h: Double, face: Typeface, size: Double, c: Any, align: Align = Align.LEFT) {
        val s = S()
        paint.style = Paint.Style.FILL; paint.color = col(c); paint.typeface = face; paint.textSize = (size * s).toFloat()
        paint.textAlign = when (align) { Align.CENTER -> Paint.Align.CENTER; Align.RIGHT -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
        val maxW = (w * s).toFloat()
        val lines = ArrayList<String>(); var cur = ""
        for (word in str.split(" ")) {
            val test = if (cur.isEmpty()) word else "$cur $word"
            if (paint.measureText(test) > maxW && cur.isNotEmpty()) { lines.add(cur); cur = word } else cur = test
        }
        if (cur.isNotEmpty()) lines.add(cur)
        val lh = size * 1.2
        val ax = when (align) { Align.CENTER -> x + w / 2; Align.RIGHT -> x + w; else -> x }
        val asc = -paint.fontMetrics.ascent / s
        var yy = y
        for ((i, ln) in lines.withIndex()) {
            if (i > 0 && yy + lh > y + h + 2) break
            cv.drawText(ln, px(ax, yy + asc * 0.86), py(ax, yy + asc * 0.86), paint)
            yy += lh
        }
    }


    /** Temperature with a hand-drawn degree ring (font degree glyphs are often oversized). */
    fun temp(v: Double, x: Double, y: Double, w: Double, face: Typeface, size: Double, c: Any, align: Align = Align.LEFT) {
        val str = "${v.roundToInt()}"
        paint.typeface = face; paint.textSize = (size * S()).toFloat()
        val tw = paint.measureText(str) / S()
        val r = size * 0.085; val total = tw + r * 3.2
        val x0 = when (align) { Align.CENTER -> x + (w - total) / 2; Align.RIGHT -> x + w - total; else -> x }
        text(str, x0, y, tw + 4, size * 1.3, face, size, c)
        ring(x0 + tw + r * 1.9, y + size * 0.3, r, c, size * 0.045)
    }

    // ---------- small folk motifs ----------
    fun flower4(cx: Double, cy: Double, r: Double, c: Any, mid: Any) {
        for (a in 0 until 4) { val an = a * PI / 2; dot(cx + cos(an) * r, cy + sin(an) * r, r * 0.75, c) }
        dot(cx, cy, r * 0.6, mid)
    }
    fun paisley(x: Double, y: Double, s: Double, c: Any, inner: Any) {
        push(x, y, s)
        shape("M 0 10 C -9 10 -10 -1 -5 -6 C -1 -10 6 -10 7 -5 C 8 -2 5 0 3 -2 C 6 3 7 9 0 10 Z", c, INK, 1.2)
        dot(-1.0, 3.0, 2.2, inner)
        pop()
    }
    fun zigzag(x0: Double, x1: Double, y: Double, h: Double, c: Any, w: Double = 1.6) {
        val sb = StringBuilder("M $x0 $y"); var up = true; var x = x0 + h
        while (x <= x1 + 0.01) { sb.append(" L $x ${if (up) y - h else y}"); up = !up; x += h }
        line(sb.toString(), c, w)
    }

    // ============================================================
    // OBJECTS
    // ============================================================
    fun umbrella() {
        val handle = "M 50 46 L 50 86 Q 50 96 41 96 Q 33 96 33 88"
        line(handle, INK, 6.0); line(handle, "#9A5527", 3.0)
        line("M 50 4 L 50 -4", INK, 3.0); dot(50.0, -5.0, 3.0, INK)
        val cano = "M 4 46 C 6 18 28 4 50 4 C 72 4 94 18 96 46 Q 84.5 38 73 46 Q 61.5 38 50 46 Q 38.5 38 27 46 Q 15.5 38 4 46 Z"
        shape(cano, "#1E1B22", INK, 2.4)
        fill("M 50 4 Q 33 14 27 46 Q 38.5 38 50 46 Z", "#B8291A")
        fill("M 50 4 Q 67 14 73 46 Q 84.5 38 96 46 C 94 18 72 4 50 4 Z", "#B8291A")
        line(cano, INK, 2.4)
        for (d in listOf("M 50 4 Q 33 14 27 46", "M 50 4 L 50 46", "M 50 4 Q 67 14 73 46")) line(d, "#FFF4DE", 1.2)
        val xs = doubleArrayOf(4.0, 27.0, 50.0, 73.0, 96.0)
        for (k in 0 until 4) for (t in listOf(0.25, 0.5, 0.75)) {
            val p = q(doubleArrayOf(xs[k], 46.0), doubleArrayOf((xs[k] + xs[k + 1]) / 2, 38.0), doubleArrayOf(xs[k + 1], 46.0), t)
            dot(p[0], p[1] - 4, 1.6, "#F5C542")
        }
    }

    fun raincoat() {
        val Y = "#F5C518"
        shape("M 30 24 L 70 24 L 76 34 L 92 70 L 81 75 L 72 52 L 75 95 L 25 95 L 28 52 L 19 75 L 8 70 L 24 34 Z", Y)
        shape("M 30 32 Q 28 6 50 6 Q 72 6 70 32 Q 50 26 30 32 Z", Y)
        fill("M 38 28 Q 38 14 50 14 Q 62 14 62 28 Q 50 33 38 28 Z", "#6B4A08")
        line("M 50 33 L 50 95", INK, 1.6)
        for (y in listOf(46.0, 60.0, 74.0)) shape("M 43 $y L 57 $y L 57 ${y + 4} L 43 ${y + 4} Z", "#8A4B22", INK, 1.2)
        line("M 31 70 L 41 70", INK, 1.4); line("M 59 70 L 69 70", INK, 1.4)
        zigzag(27.0, 73.0, 92.0, 3.0, "#B8291A", 1.4)
    }

    fun boot(c: String) {
        shape("M 20 12 L 50 12 L 50 62 Q 50 66 55 68 L 80 76 Q 92 80 92 90 L 92 95 L 18 95 L 18 88 Q 20 80 20 72 Z", c)
        fill("M 18 89 L 92 89 L 92 96 L 18 96 Z", INK)
        zigzag(22.0, 48.0, 46.0, 4.0, "#F5C542", 1.6)
        for (x in incl(26.0, 44.0, 6.0)) dot(x, 56.0, 1.6, "#FFF4DE")
        shape("M 15 6 Q 35 1 54 6 L 54 18 Q 35 14 15 18 Z", "#FFFDF6", INK, 1.8)
        for (x in incl(20.0, 50.0, 6.0)) dot(x, 12.0, 1.3, "#1F4E9C")
    }
    fun boots() {
        push(14.0, -4.0, 0.92); boot("#8E2A3A"); pop()
        push(-6.0, 6.0, 0.92); boot("#C2185B"); pop()
    }

    fun jacket() {
        val B = "#1F4E9C"
        shape("M 34 12 L 66 12 L 84 24 L 95 80 L 81 83 L 74 50 L 75 95 L 25 95 L 26 50 L 19 83 L 5 80 L 16 24 Z", B)
        for (y in listOf(36.0, 52.0, 68.0, 84.0)) line("M 26 $y Q 50 ${y + 5} 74 $y", "#0E2E66", 1.6)
        line("M 84 40 Q 88 41 90 39", "#0E2E66", 1.4); line("M 16 40 Q 12 41 10 39", "#0E2E66", 1.4)
        line("M 50 16 L 50 95", "#F5C542", 2.0)
        paisley(36.0, 60.0, 0.9, "#E2577F", "#F5C542"); paisley(64.0, 76.0, 0.9, "#F5C542", "#E2577F")
        shape("M 32 14 Q 50 28 68 14 Q 64 3 50 5 Q 36 3 32 14 Z", "#FFFDF6", INK, 1.8)
        for (x in incl(38.0, 62.0, 6.0)) dot(x, 12.0, 1.2, "#C2185B")
    }

    fun hat() {
        shape(ellD(50.0, 64.0, 47.0, 15.0), "#E9C46A")
        for (a in 0 until 18) { val an = a / 18.0 * PI * 2
            line("M ${50 + cos(an) * 30} ${64 + sin(an) * 9} L ${50 + cos(an) * 44} ${64 + sin(an) * 14}", "#B5822C", 1.0) }
        shape("M 27 64 Q 26 30 50 30 Q 74 30 73 64 Q 50 70 27 64 Z", "#F0D080")
        shape("M 27.5 54 Q 50 60 72.5 54 L 73 62 Q 50 68 27 62 Z", "#B8291A", INK, 1.6)
        for (x in incl(32.0, 68.0, 6.0)) dot(x, 59.5 + sin((x - 32) / 36 * PI) * 1.5, 1.2, "#F5C542")
        flower4(68.0, 52.0, 3.0, "#E2577F", "#F5C542")
    }

    fun shades() {
        line("M 13 44 Q 4 44 2 56", INK, 3.0); line("M 87 44 Q 96 44 98 56", INK, 3.0)
        line("M 44 46 Q 50 40 56 46", INK, 3.0)
        shape(ellD(29.0, 52.0, 17.0, 15.0), "#1E1B22", "#B8291A", 3.0)
        shape(ellD(71.0, 52.0, 17.0, 15.0), "#1E1B22", "#B8291A", 3.0)
        for (cx in listOf(29.0, 71.0)) { line("M ${cx - 9} 48 Q ${cx - 6} 42 $cx 41", "#FFF4DE", 2.0); dot(cx + 8, 58.0, 1.8, "#F5C542") }
    }

    fun matka() {
        shape("M 31 28 L 69 28 L 65 37 Q 92 48 88 70 Q 83 96 50 96 Q 17 96 12 70 Q 8 48 35 37 Z", "#B5532E")
        shape(ellD(50.0, 28.0, 20.0, 5.0), "#8E3A1E", INK, 1.8)
        fill(ellD(50.0, 28.0, 15.0, 3.0), "#3A2418")
        line("M 18 56 Q 50 66 82 56", "#FFF4DE", 2.0)
        line("M 15 76 Q 50 88 85 76", "#FFF4DE", 2.0)
        for (i in 0 until 9) { val x = 22.0 + i * 7; val y = 66 + sin(i / 8.0 * PI) * 3.5; dot(x, y, 1.8, "#F5C542") }
        line("M 24 48 Q 30 44 34 46", "#FFF4DE", 1.6)
        dot(74.0, 50.0, 1.6, "#AEE0F0"); dot(78.0, 58.0, 1.2, "#AEE0F0")
    }

    fun pankha() {
        shape("M 47 58 L 53 58 L 54 98 L 46 98 Z", "#9A5527", INK, 1.8)
        for (a in 0 until 24) { val an = a / 24.0 * PI * 2; dot(50 + cos(an) * 36, 34 + sin(an) * 36, 2.4, if (a % 2 == 1) "#B8291A" else "#F5C542") }
        shape(ellD(50.0, 34.0, 33.0, 33.0), "#E9C46A")
        for (a in 0 until 16) { val an = a / 16.0 * PI * 2; line("M 50 34 L ${50 + cos(an) * 33} ${34 + sin(an) * 33}", "#B5822C", 1.0) }
        ring(50.0, 34.0, 22.0, "#B8291A", 4.0); ring(50.0, 34.0, 12.0, "#0F6E73", 4.0)
        dot(50.0, 34.0, 5.0, "#E2577F"); ring(50.0, 34.0, 33.0, INK, 2.2)
    }

    fun kurta() {
        shape("M 36 8 L 64 8 L 86 20 L 97 50 L 84 54 L 76 34 L 76 96 L 24 96 L 24 34 L 16 54 L 3 50 L 14 20 Z", "#E2577F")
        for (y in excl(26.0, 84.0, 10.0)) {
            val off = if (((y / 10).toInt()) % 2 == 1) 5.0 else 0.0
            for (x in excl(30.0 + off, 72.0, 10.0)) flower4(x, y, 1.6, "#FFF4DE", "#F5C542")
        }
        shape("M 24 84 L 76 84 L 76 96 L 24 96 Z", "#0F6E73", INK, 1.8)
        zigzag(26.0, 74.0, 92.0, 3.0, "#F5C542", 1.4)
        shape("M 43 8 Q 50 18 57 8 Z", "#0F6E73", INK, 1.6)
        line("M 50 16 L 50 42", INK, 1.6)
        for (y in listOf(22.0, 30.0, 38.0)) dot(50.0, y, 1.6, "#F5C542")
        line("M 84 54 L 97 50", "#0F6E73", 3.0); line("M 16 54 L 3 50", "#0F6E73", 3.0)
    }

    fun jhola() {
        line("M 26 44 Q 28 2 50 2 Q 72 2 74 44", INK, 7.0); line("M 26 44 Q 28 2 50 2 Q 72 2 74 44", "#C2185B", 4.0)
        shape("M 16 40 L 84 40 L 86 94 Q 50 98 14 94 Z", "#F2D48A")
        for (x in excl(18.0, 84.0, 8.0)) shape("M $x 40 L ${x + 8} 40 L ${x + 4} 47 Z", "#B8291A", INK, 1.0)
        ring(50.0, 68.0, 15.0, "#0F6E73", 3.0); ring(50.0, 68.0, 8.0, "#B8291A", 3.0); dot(50.0, 68.0, 3.0, "#0F6E73")
        for (a in 0 until 8) { val an = a / 8.0 * PI * 2; dot(50 + cos(an) * 21, 68 + sin(an) * 21, 2.0, "#C2185B") }
        for (x in incl(18.0, 82.0, 6.0)) line("M $x 95 L $x 100", INK, 1.4)
    }

    fun kulhad() {
        for (s in listOf("M 40 30 C 34 22 46 16 40 6", "M 52 30 C 46 20 58 14 52 2", "M 63 30 C 57 22 69 16 63 8")) line(s, "#FFF8EA", 2.4)
        shape("M 26 40 L 74 40 L 65 92 Q 50 97 35 92 Z", "#B5532E")
        line("M 29 55 L 71 55", "#FFF4DE", 1.6)
        for (x in incl(33.0, 67.0, 6.0)) dot(x, 63.0, 1.6, "#F5C542")
        line("M 32 72 L 68 72", "#FFF4DE", 1.6)
        shape(ellD(50.0, 40.0, 24.0, 6.0), "#8E3A1E", INK, 1.8)
        fill(ellD(50.0, 40.0, 19.0, 4.0), "#C88A4A")
    }

    fun pakoras() {
        shape("M 2 76 Q 50 50 98 76 Q 50 100 2 76 Z", "#4C9A3C")
        line("M 6 76 Q 50 66 94 76", "#2F6A26", 1.6)
        for (x in excl(16.0, 90.0, 10.0)) line("M $x 74 L ${x + 6} ${68 + abs(50 - x) / 8}", "#2F6A26", 1.0)
        val blobs = listOf(doubleArrayOf(30.0, 70.0, 13.0), doubleArrayOf(52.0, 66.0, 14.0), doubleArrayOf(72.0, 72.0, 12.0), doubleArrayOf(44.0, 80.0, 12.0), doubleArrayOf(64.0, 82.0, 11.0))
        for (b in blobs) {
            val x = b[0]; val y = b[1]; val r = b[2]
            shape("M ${x - r} $y Q ${x - r} ${y - r} ${x - r * 0.2} ${y - r * 0.9} Q ${x + r * 0.4} ${y - r * 1.2} ${x + r} ${y - r * 0.3} Q ${x + r * 1.1} ${y + r * 0.7} $x ${y + r * 0.8} Q ${x - r * 1.1} ${y + r * 0.8} ${x - r} $y Z", "#D98E2B", INK, 1.6)
            dot(x - r * 0.3, y - r * 0.3, 1.2, "#7A3E10"); dot(x + r * 0.3, y + r * 0.1, 1.2, "#7A3E10"); dot(x, y - r * 0.6, 1.0, "#F5C542")
        }
        shape("M 78 58 Q 92 50 96 38 Q 98 46 90 56 Q 84 62 78 60 Z", "#3E8E2E", INK, 1.4)
    }

    fun monkeycap() {
        shape("M 16 74 Q 12 14 50 12 Q 88 14 84 74 L 84 94 L 16 94 Z", "#8E2A3A")
        for (y in listOf(28.0, 44.0)) zigzag(20.0, 80.0, y, 4.0, "#F2B544", 1.8)
        shape("M 16 80 L 84 80 L 84 95 L 16 95 Z", "#F2B544", INK, 1.8)
        for (x in incl(20.0, 80.0, 5.0)) line("M $x 82 L $x 93", "#B5822C", 1.0)
        shape(ellD(50.0, 62.0, 22.0, 13.0), "#E0A47A", INK, 2.0)
        fill(ellD(40.0, 61.0, 4.5, 3.5), "#FFFDF6"); fill(ellD(60.0, 61.0, 4.5, 3.5), "#FFFDF6")
        dot(41.5, 61.5, 2.2, INK); dot(61.5, 61.5, 2.2, INK)
        dot(50.0, 68.0, 1.2, "#B8291A")
        dot(50.0, 9.0, 9.0, "#F2B544"); ring(50.0, 9.0, 9.0, INK, 2.0)
        for (a in 0 until 8) { val an = a / 8.0 * PI * 2; dot(50 + cos(an) * 5, 9 + sin(an) * 5, 1.0, "#B5822C") }
    }

    fun muffler() {
        val A = "#0F6E73"; val B2 = "#F2B544"
        shape("M 54 40 L 74 88 L 58 92 L 42 44 Z", A)
        for (t in listOf(0.35, 0.6)) line("M ${48 + t * 22} ${42 + t * 46} L ${42 + t * 20 + 12} ${44 + t * 46 - 4}", B2, 3.0)
        for (i in 0..5) { val x = 58 + i * 3.2; val y = 92 - i * 0.8; line("M $x $y L ${x + 1} ${y + 8}", INK, 1.4) }
        shape("M 8 30 Q 50 10 92 30 L 90 46 Q 50 28 10 46 Z", A)
        line("M 30 22 L 30 39", B2, 3.0); line("M 50 19 L 50 35", B2, 3.0); line("M 70 22 L 70 39", B2, 3.0)
        for (i in 0 until 8) dot(14.0 + i * 10, 38 - sin(i / 7.0 * PI) * 6, 1.4, "#FFF4DE")
        shape(ellD(48.0, 42.0, 10.0, 8.0), A, INK, 2.0)
    }

    fun shawl() {
        val R = "#B8291A"
        shape("M 6 18 Q 50 4 94 18 L 86 94 Q 50 84 14 94 Z", R)
        for (y in incl(26.0, 70.0, 11.0)) {
            val off = if (((y / 11).toInt()) % 2 == 1) 6.0 else 0.0
            for (x in excl(24.0 + off, 80.0, 12.0)) dot(x, y, 1.5, "#F2B544")
        }
        shape("M 13 80 Q 50 70 87 80 L 86 94 Q 50 84 14 94 Z", "#F2B544", INK, 1.6)
        for (i in 0 until 5) paisley(22.0 + i * 14, 84 - sin(i / 4.0 * PI) * 2.6, 0.55, "#0F6E73", R)
        for (i in 0..14) { val x = 15 + i * 5.1; val y = 94 - sin(i / 14.0 * PI) * 10; line("M $x $y L $x ${y + 5}", INK, 1.2) }
        line("M 10 26 Q 50 14 90 26", "#F2B544", 2.0)
    }

    fun kite() {
        line("M 50 94 Q 30 98 22 88 Q 10 76 -2 82", "#FFF8EA", 1.4)
        shape("M 50 4 L 88 44 L 50 92 L 12 44 Z", "#F06D4F")
        fill("M 50 4 L 88 44 L 50 92 Z", "#F6B93B"); line("M 50 4 L 88 44 L 50 92 L 12 44 Z", INK, 2.2)
        shape("M 50 60 L 62 74 L 50 92 L 38 74 Z", "#0F6E73", INK, 1.6)
        line("M 50 4 L 50 92", INK, 1.6); line("M 12 44 Q 50 26 88 44", INK, 1.6)
        shape("M 50 92 L 41 100 L 59 100 Z", "#C2185B", INK, 1.6)
        dot(50.0, 44.0, 2.4, "#FFF4DE")
    }

    fun dupatta() {
        shape("M 4 30 C 28 8 52 48 96 20 L 96 44 C 54 72 28 34 4 54 Z", "#C2185B")
        line("M 4 36 C 28 14 52 54 96 26", "#F6B93B", 2.0); line("M 4 48 C 28 28 54 66 96 38", "#F6B93B", 2.0)
        for (i in 0 until 8) { val t = i / 7.0; val x = 8 + t * 84; val y = 42 + sin(t * PI * 1.6 + 0.6) * 9 - t * 6; dot(x, y, 1.6, "#FFF4DE") }
        for (i in 0 until 6) { val y = 22 + i * 4.2; line("M 96 $y L 100 ${y + 1}", INK, 1.2) }
    }

    fun diya() {
        dot(88.0, 30.0, 13.0, ca("#F5C542", 0.25))
        shape("M 88 50 Q 79 36 88 18 Q 98 36 88 50 Z", "#F6A21B", INK, 1.6)
        fill("M 88 48 Q 84 40 88 30 Q 92 40 88 48 Z", "#FFF2A8")
        shape("M 8 62 Q 50 100 92 58 Q 92 52 84 52 Q 70 60 50 60 Q 28 60 8 62 Z", "#B5532E")
        fill(ellD(48.0, 61.0, 34.0, 5.0), "#7A3418")
        for (i in 0 until 7) { val x = 22.0 + i * 9; dot(x, 74 + sin(i / 6.0 * PI) * 4, 1.8, "#F5C542") }
        line("M 18 68 Q 50 88 82 66", "#FFF4DE", 1.4)
    }
    fun diyaSmall() { push(14.0, 20.0, 0.72); diya(); pop() }

    // ============================================================
    // DECOR
    // ============================================================
    fun folkSun(cx: Double, cy: Double, r: Double, hot: Boolean) {
        val rays = 14
        for (i in 0 until rays) {
            val a = i.toDouble() / rays * PI * 2; val a1 = a - PI / rays * 0.7; val a2 = a + PI / rays * 0.7
            val R = r * (if (i % 2 == 1) 1.5 else 1.75)
            shape("M ${cx + cos(a1) * r * 1.02} ${cy + sin(a1) * r * 1.02} L ${cx + cos(a) * R} ${cy + sin(a) * R} L ${cx + cos(a2) * r * 1.02} ${cy + sin(a2) * r * 1.02} Z",
                if (i % 2 == 1) "#B8291A" else "#F6A21B", INK, 1.2)
        }
        shape(ellD(cx, cy, r, r), if (hot) "#F6A21B" else "#F5C542", INK, 1.8)
        ring(cx, cy, r * 0.78, "#B8291A", 1.0)
        line("M ${cx - r * 0.5} ${cy - r * 0.12} Q ${cx - r * 0.3} ${cy + r * 0.05} ${cx - r * 0.1} ${cy - r * 0.12}", INK, 1.4)
        line("M ${cx + r * 0.1} ${cy - r * 0.12} Q ${cx + r * 0.3} ${cy + r * 0.05} ${cx + r * 0.5} ${cy - r * 0.12}", INK, 1.4)
        line("M ${cx - r * 0.25} ${cy + r * 0.32} Q $cx ${cy + r * 0.5} ${cx + r * 0.25} ${cy + r * 0.32}", "#B8291A", 1.6)
        dot(cx, cy - r * 0.45, r * 0.08, "#B8291A")
    }

    fun cloud(cx: Double, cy: Double, s: Double, c: String, swirl: String = "#F2B544") {
        val lobes = listOf(doubleArrayOf(-22.0, 4.0, 13.0), doubleArrayOf(-6.0, -6.0, 17.0), doubleArrayOf(14.0, -2.0, 14.0), doubleArrayOf(26.0, 7.0, 10.0), doubleArrayOf(2.0, 8.0, 14.0), doubleArrayOf(-16.0, 10.0, 10.0))
        push(cx, cy, s)
        for (l in lobes) line(ellD(l[0], l[1], l[2], l[2]), INK, 4.2)
        for (l in lobes) fill(ellD(l[0], l[1], l[2], l[2]), c)
        line("M -6 -4 C -6 -12 4 -12 4 -5 C 4 0 -2 1 -3 -3", swirl, 1.6)
        line("M 14 4 C 14 -2 21 -2 21 3", swirl, 1.4)
        pop()
    }

    fun drop(x: Double, y: Double, s: Double, c: String) { push(x, y, s); shape("M 0 -6 Q 4 0 4 2 Q 4 6 0 6 Q -4 6 -4 2 Q -4 0 0 -6 Z", c, INK, 0.9); pop() }

    fun flake(x: Double, y: Double, r: Double, c: String, w: Double = 1.4) {
        for (i in 0 until 3) { val a = i * PI / 3; val dx = cos(a) * r; val dy = sin(a) * r; line("M ${x - dx} ${y - dy} L ${x + dx} ${y + dy}", c, w) }
        for (i in 0 until 6) { val a = i * PI / 3; dot(x + cos(a) * r, y + sin(a) * r, w * 0.9, c) }
        dot(x, y, w, c)
    }

    fun sparkle(x: Double, y: Double, r: Double, c: String) =
        fill("M $x ${y - r} Q $x $y ${x + r} $y Q $x $y $x ${y + r} Q $x $y ${x - r} $y Q $x $y $x ${y - r} Z", c)

    fun crescent(cx: Double, cy: Double, r: Double, bg: String) {
        dot(cx, cy, r * 1.5, ca("#F2A7B8", 0.12))
        shape(ellD(cx, cy, r, r), "#F2A7B8", "#F7C9D4", 1.0)
        fill(ellD(cx + r * 0.45, cy - r * 0.25, r * 0.85, r * 0.85), bg)
    }

    fun bolt(x: Double, y: Double, s: Double) { push(x, y, s); shape("M 6 0 L 20 0 L 12 14 L 22 14 L 2 40 L 8 20 L 0 20 Z", "#F5B82E", INK, 1.4); pop() }

    fun windCurl(x: Double, y: Double, s: Double, c: String) { push(x, y, s); line("M 0 0 L 40 0 C 52 0 52 -14 42 -14 C 36 -14 36 -6 42 -7", c, 2.2); pop() }

    fun decor(key: String, w: Double, h: Double, night: Boolean, inside: ((Double, Double) -> Boolean)?, bgCol: String) {
        val ok = inside ?: { _, _ -> true }
        val R = Rng(7)
        val mn = min(w, h)
        when (key) {
            "sunny" -> folkSun(w * 0.72, h * 0.22, mn * 0.11, false)
            "hot" -> folkSun(w * 0.5, h * 0.22, mn * 0.14, true)
            "cloudy" -> {
                if (night) crescent(w * 0.68, h * 0.17, mn * 0.07, bgCol) else folkSun(w * 0.68, h * 0.17, mn * 0.07, false)
                cloud(w * 0.52, h * 0.3, mn / 130, "#FFFDF6"); cloud(w * 0.26, h * 0.42, mn / 200, "#F7E9C8")
            }
            "rain", "storm" -> {
                var y = h * 0.34
                while (y < h * 0.95) {
                    var x = w * 0.1 + R.next() * 8
                    while (x < w * 0.95) {
                        val xx = x + R.next() * 6; val yy = y + R.next() * 6
                        if (ok(xx, yy)) drop(xx, yy, mn / 140, if (key == "rain") "#7EC8E3" else "#9DB4F0")
                        x += w * 0.13
                    }
                    y += h * 0.1
                }
                cloud(w * 0.5, h * 0.26, mn / 120, if (key == "rain") "#E9F1F4" else "#8E9AC6", if (key == "rain") "#7EC8E3" else "#F5B82E")
                if (key == "storm") bolt(w * 0.52, h * 0.3, mn / 150)
            }
            "snow" -> for (i in 0 until 16) { val x = w * (0.08 + R.next() * 0.84); val y = h * (0.1 + R.next() * 0.38); if (ok(x, y)) flake(x, y, 2.2 + R.next() * 2.5, "#1F4E9C", 1.0) }
            "fog" -> for (i in 0 until 4) {
                val y = h * (0.22 + i * 0.12); val sb = StringBuilder("M ${w * 0.08} $y"); var x = w * 0.08
                while (x < w * 0.92) { sb.append(" Q ${x + 3} ${y - 3} ${x + 6} $y Q ${x + 9} ${y + 3} ${x + 12} $y"); x += 12 }
                line(sb.toString(), ca("#FFFFFF", 0.75), 2.4)
            }
            "cold" -> for (i in 0 until 9) { val x = w * (0.1 + R.next() * 0.8); val y = h * (0.06 + R.next() * 0.32); if (ok(x, y)) flake(x, y, 1.8 + R.next() * 1.6, "#FBEBC8", 0.9) }
            "windy" -> { windCurl(w * 0.14, h * 0.18, mn / 110, "#FFF8EA"); windCurl(w * 0.42, h * 0.3, mn / 150, "#F6B93B") }
            "night" -> {
                crescent(w * 0.56, h * 0.22, mn * 0.1, bgCol)
                for (i in 0 until 9) { val x = w * (0.1 + R.next() * 0.8); val y = h * (0.06 + R.next() * 0.42); if (ok(x, y)) sparkle(x, y, 2 + R.next() * 3, "#F5C542") }
            }
        }
    }

    private class Place(val fn: () -> Unit, val dx: Double, val dy: Double, val sc: Double, val rot: Double)
    private val scenes: Map<String, List<Place>> = mapOf(
        "sunny" to listOf(Place({ hat() }, 0.0, 0.0, 1.0, -6.0), Place({ shades() }, 0.0, 0.12, 0.92, 4.0)),
        "hot" to listOf(Place({ matka() }, 0.0, 0.0, 1.0, 0.0), Place({ pankha() }, 0.0, 0.0, 0.98, 14.0)),
        "cloudy" to listOf(Place({ kurta() }, 0.0, 0.0, 1.0, 0.0), Place({ jhola() }, 0.0, 0.06, 0.88, 6.0)),
        "rain" to listOf(Place({ raincoat() }, 0.04, 0.02, 1.0, 0.0), Place({ umbrella() }, -0.06, -0.04, 1.08, -14.0)),
        "storm" to listOf(Place({ kulhad() }, 0.06, 0.02, 0.92, 0.0), Place({ pakoras() }, -0.04, 0.04, 1.02, 0.0)),
        "snow" to listOf(Place({ jacket() }, 0.0, 0.0, 1.0, 0.0), Place({ boots() }, 0.0, 0.06, 0.92, 0.0)),
        "fog" to listOf(Place({ monkeycap() }, 0.0, 0.0, 1.0, 0.0), Place({ muffler() }, 0.0, 0.04, 0.98, 0.0)),
        "cold" to listOf(Place({ shawl() }, 0.0, 0.0, 1.0, -4.0), Place({ kulhad() }, -0.02, 0.06, 0.82, 0.0)),
        "windy" to listOf(Place({ kite() }, 0.02, -0.12, 0.96, -16.0), Place({ dupatta() }, 0.0, 0.14, 1.0, 0.0)),
        "night" to listOf(Place({ diya() }, 0.0, 0.04, 1.0, 0.0), Place({ diyaSmall() }, 0.0, 0.06, 1.0, 0.0)),
    )
    private val icons: Map<String, () -> Unit> = mapOf("sunny" to { hat() }, "hot" to { matka() }, "cloudy" to { kurta() }, "rain" to { umbrella() },
        "storm" to { kulhad() }, "snow" to { boots() }, "fog" to { monkeycap() }, "cold" to { shawl() }, "windy" to { kite() }, "night" to { diya() })

    fun scene(key: String, w: Double, h: Double, night: Boolean, inside: ((Double, Double) -> Boolean)?, bgCol: String) {
        decor(key, w, h, night, inside, bgCol)
        val sz = min(w * 0.5, h * 0.64); val pad = w * 0.03
        val pos = listOf(doubleArrayOf(pad, h - sz - h * 0.03), doubleArrayOf(w - sz - pad, h - sz - h * 0.03))
        scenes.getValue(key).forEachIndexed { i, pl ->
            val s = sz / 100 * pl.sc
            val cx = pos[i][0] + sz / 2 + pl.dx * w; val cy = pos[i][1] + sz / 2 + pl.dy * h
            push(cx, cy, s, pl.rot); push(-50.0, -50.0); pl.fn(); pop(); pop()
        }
    }

    // ============================================================
    // FRAME, BACKGROUND, LAYOUTS
    // ============================================================
    fun background(W: Double, H: Double, th: Theme) {
        fill("M 0 0 L $W 0 L $W $H L 0 $H Z", th.bg)
        val R = Rng(42); val n = (W * H / 90).toInt(); val g = ca(th.grain, 0.07)
        for (i in 0 until n) dot(R.next() * W, R.next() * H, 0.3 + R.next() * 0.9, g)
    }

    fun border(W: Double, H: Double, th: Theme) {
        val i = 7.0; val r = 16.0
        line("M ${i + r} $i L ${W - i - r} $i Q ${W - i} $i ${W - i} ${i + r} L ${W - i} ${H - i - r} Q ${W - i} ${H - i} ${W - i - r} ${H - i} L ${i + r} ${H - i} Q $i ${H - i} $i ${H - i - r} L $i ${i + r} Q $i $i ${i + r} $i Z", th.border, 1.4)
        val j = 11.5; val step = 7.0
        for (x in incl(j + 12, W - j - 12, step)) { dot(x, j, 1.1, th.dots); dot(x, H - j, 1.1, th.dots) }
        for (y in incl(j + 12, H - j - 12, step)) { dot(j, y, 1.1, th.dots); dot(W - j, y, 1.1, th.dots) }
        for (p in listOf(doubleArrayOf(j + 3, j + 3), doubleArrayOf(W - j - 3, j + 3), doubleArrayOf(j + 3, H - j - 3), doubleArrayOf(W - j - 3, H - j - 3)))
            flower4(p[0], p[1], 2.4, th.dots, th.border)
    }

    private fun archD(x: Double, y: Double, w: Double, h: Double): String {
        val sh = min(h * 0.26, w * 0.34)
        return "M $x ${y + h} L $x ${y + sh} C $x ${y + sh * 0.45} ${x + w * 0.3} ${y + sh * 0.38} ${x + w * 0.42} ${y + sh * 0.12} Q ${x + w * 0.5} $y ${x + w * 0.5} ${y - sh * 0.18} Q ${x + w * 0.5} $y ${x + w * 0.58} ${y + sh * 0.12} C ${x + w * 0.7} ${y + sh * 0.38} ${x + w} ${y + sh * 0.45} ${x + w} ${y + sh} L ${x + w} ${y + h} Z"
    }
    private fun archPanel(x: Double, y: Double, w: Double, h: Double, th: Theme): (Double, Double) -> Boolean {
        shape(archD(x - 4, y - 4, w + 8, h + 8), th.border, INK, 1.6)
        shape(archD(x, y, w, h), th.panel, INK, 1.4)
        dot(x + w / 2, y - min(h * 0.26, w * 0.34) * 0.18 - 9, 3.0, th.dots)
        return { px, py ->
            val sh = min(h * 0.26, w * 0.34); val m = 6.0
            if (px < m || px > w - m || py > h - m) false
            else if (py > sh) true
            else { val dx = abs(px - w / 2) / (w / 2); py > sh * (1 - cos(dx * PI / 2) * 0.9) + m }
        }
    }

    private fun fmtT(v: Double) = "${v.roundToInt()}°"
    private fun word(lang: String, key: String) = (Art.WORDS[lang] ?: Art.WORDS.getValue("hi")).getValue(key)

    private fun textBlock(x: Double, y: Double, w: Double, m: Model, th: Theme, lang: String, big: Boolean) {
        val wd = word(lang, m.key)
        val fit = if (wd.length > 6) 0.66 else if (wd.length > 4) 0.8 else 1.0
        text(wd, x, y + (1 - fit) * 8, w * 0.62, 28.0, fonts.indic, (if (big) 22.0 else 19.0) * fit, th.accent)
        text(Art.LABELS.getValue(m.key), x, y + (if (big) 4 else 2), w, 12.0, fonts.sansBold, 8.5, th.text, Align.RIGHT)
        text("${m.place} · ${m.time}".uppercase(), x, y + (if (big) 17 else 14), w, 12.0, fonts.sansBold, 7.0, ca(th.text, 0.72), Align.RIGHT)
        temp(m.temp, x - 2, y + (if (big) 30 else 22), w, fonts.serif, if (big) 60.0 else 50.0, th.text)
        text("H ${fmtT(m.hi)}   L ${fmtT(m.lo)}   feels ${fmtT(m.feels)}", x, y + (if (big) 102 else 80), w, 14.0, fonts.sansBold, 9.0, th.sub)
        text(m.advice, x, y + (if (big) 118 else 94), w, 30.0, fonts.italic, if (big) 12.5 else 11.0, th.text)
    }

    private fun layoutSmall(W: Double, m: Model, th: Theme, lang: String) {
        push(10.0, 8.0); scene(m.key, W - 20, 92.0, m.night, null, th.bg); pop()
        temp(m.temp, 16.0, 98.0, 80.0, fonts.serif, 38.0, th.text)
        val wd = word(lang, m.key)
        text(wd, W - 96, 102.0, 80.0, 22.0, fonts.indic, if (wd.length > 6) 11.0 else 15.0, th.accent, Align.RIGHT)
        text("${fmtT(m.hi)} / ${fmtT(m.lo)}", W - 96, 124.0, 80.0, 14.0, fonts.sansBold, 10.0, th.sub, Align.RIGHT)
        text(m.place.uppercase(), 23.0, 139.0, W - 46, 11.0, fonts.sansBold, 7.0, ca(th.text, 0.75))
    }

    private fun layoutMedium(W: Double, H: Double, m: Model, th: Theme, lang: String) {
        val ax = 18.0; val ay = 24.0; val aw = 128.0; val ah = H - ay - 16
        val inside = archPanel(ax, ay, aw, ah, th)
        push(ax, ay); scene(m.key, aw, ah, m.night, inside, th.panel); pop()
        textBlock(162.0, 17.0, W - 162 - 16, m, th, lang, false)
    }

    private fun layoutLarge(W: Double, m: Model, th: Theme, lang: String) {
        val ax = 18.0; val ay = 30.0; val aw = 140.0; val ah = 170.0
        val inside = archPanel(ax, ay, aw, ah, th)
        push(ax, ay); scene(m.key, aw, ah, m.night, inside, th.panel); pop()
        textBlock(174.0, 24.0, W - 174 - 16, m, th, lang, true)
        val top = 212.0
        var x0 = 24.0
        while (x0 < W - 24) { val k = ((x0 / 9).toInt()) % 3; dot(x0, top, if (k != 0) 1.0 else 1.8, if (k != 0) th.border else th.dots); x0 += 9 }
        val days = m.daily.take(5); val cw = (W - 36) / max(1, days.size)
        days.forEachIndexed { i, d ->
            val x = 18 + i * cw; val dth = Art.THEMES.getValue(d.key)
            shape("M ${x + 4} ${top + 14} L ${x + cw - 4} ${top + 14} L ${x + cw - 4} ${top + 124} L ${x + 4} ${top + 124} Z", dth.bg, th.border, 1.2)
            text(Art.DAYS.getValue("en")[d.dow].uppercase(), x, top + 19, cw, 12.0, fonts.sansBold, 8.0, dth.text, Align.CENTER)
            text((Art.DAYS[lang] ?: Art.DAYS.getValue("hi"))[d.dow], x, top + 31, cw, 14.0, fonts.indic, if (lang == "ta") 7.5 else 9.0, dth.accent, Align.CENTER)
            val s = min(cw - 18, 40.0) / 100
            push(x + cw / 2, top + 68, s); push(-50.0, -50.0); icons.getValue(d.key)(); pop(); pop()
            temp(d.hi, x, top + 90, cw, fonts.serif, 14.0, dth.text, Align.CENTER)
            text(fmtT(d.lo), x, top + 107, cw, 12.0, fonts.sansBold, 9.0, dth.sub, Align.CENTER)
        }
    }

    fun widget(family: String, W: Double, H: Double, m: Model, lang: String) {
        val th = Art.THEMES.getValue(m.key)
        background(W, H, th)
        when (family) {
            "small" -> layoutSmall(W, m, th, lang)
            "large" -> layoutLarge(W, m, th, lang)
            else -> layoutMedium(W, H, m, th, lang)
        }
        border(W, H, th)
    }
}
