package com.rangmausam

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.RemoteViews
import java.util.Locale

/** Settings, cached forecast and location, kept in SharedPreferences. */
object Store {
    private const val P = "rang_mausam"
    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun lang(c: Context): String = sp(c).getString("lang", "hi") ?: "hi"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun fahrenheit(c: Context): Boolean = sp(c).getBoolean("fahrenheit", false)
    fun setFahrenheit(c: Context, v: Boolean) = sp(c).edit().putBoolean("fahrenheit", v).apply()
    /** "gps" follows the phone, "city" uses the saved city. */
    fun mode(c: Context): String = sp(c).getString("mode", "gps") ?: "gps"

    fun saveLocation(c: Context, lat: Double, lon: Double, place: String, mode: String) =
        sp(c).edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).putString("place", place).putString("mode", mode).apply()
    fun lat(c: Context): Double = sp(c).getFloat("lat", 12.9716f).toDouble()
    fun lon(c: Context): Double = sp(c).getFloat("lon", 77.5946f).toDouble()
    fun place(c: Context): String = sp(c).getString("place", "Bengaluru") ?: "Bengaluru"

    fun saveForecast(c: Context, json: String) = sp(c).edit().putString("json", json).putLong("at", System.currentTimeMillis()).apply()
    fun forecast(c: Context): String? = sp(c).getString("json", null)

    private var cachedFonts: Fonts? = null
    fun fonts(c: Context): Fonts = cachedFonts ?: Fonts(
        Typeface.createFromAsset(c.assets, "fonts/PlayfairDisplay-Bold.ttf"),
        Typeface.createFromAsset(c.assets, "fonts/Lora-MediumItalic.ttf"),
        Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD),
        Typeface.DEFAULT_BOLD,
    ).also { cachedFonts = it }

    fun hasLocationPermission(c: Context) =
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Best cached fix from any provider; null when there is none or no permission. */
    fun lastFix(c: Context): Location? {
        if (!hasLocationPermission(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            } catch (e: Exception) { }
        }
        return best
    }

    @Suppress("DEPRECATION")
    fun placeName(c: Context, lat: Double, lon: Double): String? = try {
        val a = Geocoder(c, Locale.ENGLISH).getFromLocation(lat, lon, 1)?.firstOrNull()
        a?.locality ?: a?.subAdminArea ?: a?.adminArea
    } catch (e: Exception) { null }
}

class RangWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try { refresh(context, mgr, ids, network = true) } finally { pending.finish() }
        }.start()
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, opts: Bundle) {
        val pending = goAsync()
        Thread {
            try { refresh(context, mgr, intArrayOf(id), network = false) } finally { pending.finish() }
        }.start()
    }

    companion object {
        /** Refresh every placed widget (used by the app's Refresh button). */
        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, RangWidget::class.java))
            if (ids.isNotEmpty()) Thread { refresh(context, mgr, ids, network = true) }.start()
        }

        /** Loads (or reuses) the forecast and redraws the given widgets. Call off the main thread. */
        fun currentModel(context: Context, network: Boolean): Model {
            val f = Store.fahrenheit(context)
            if (network) {
                try {
                    var lat = Store.lat(context); var lon = Store.lon(context); var place = Store.place(context)
                    if (Store.mode(context) == "gps") {
                        val fix = Store.lastFix(context)
                        if (fix != null) {
                            lat = fix.latitude; lon = fix.longitude
                            place = Store.placeName(context, lat, lon) ?: place
                            Store.saveLocation(context, lat, lon, place, "gps")
                        }
                    }
                    val json = Weather.get(Weather.forecastUrl(lat, lon, f))
                    Store.saveForecast(context, json)
                    return Weather.classify(json, place, f)
                } catch (e: Exception) { /* fall through to cache */ }
            }
            val cached = Store.forecast(context)
            if (cached != null) {
                try { return Weather.classify(cached, Store.place(context), f).copy(time = if (network) "offline" else "updated earlier") } catch (e: Exception) { }
            }
            return Weather.demo("cloudy", "No forecast yet").copy(advice = "Open Rang Mausam to set your place.")
        }

        fun refresh(context: Context, mgr: AppWidgetManager, ids: IntArray, network: Boolean) {
            val model = currentModel(context, network)
            for (id in ids) {
                try { mgr.updateAppWidget(id, views(context, mgr, id, model)) } catch (e: Exception) { }
            }
        }

        /** Picks small, medium or large from the widget's current size and renders it. */
        fun views(context: Context, mgr: AppWidgetManager, id: Int, model: Model): RemoteViews {
            val o = mgr.getAppWidgetOptions(id)
            val portrait = context.resources.configuration.orientation != android.content.res.Configuration.ORIENTATION_LANDSCAPE
            var wDp = (if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH)).toDouble()
            var hDp = (if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)).toDouble()
            if (wDp <= 0) wDp = 250.0
            if (hDp <= 0) hDp = 110.0
            val family = when {
                wDp / hDp >= 1.5 -> "medium"
                wDp >= 230 && hDp >= 230 -> "large"
                else -> "small"
            }
            val (lw, lh) = Art.SIZES.getValue(family)
            val density = context.resources.displayMetrics.density
            val scale = (minOf(wDp / lw, hDp / lh) * density).toFloat().coerceIn(1f, 4f)
            val bmp = Art.render(family, model, Store.lang(context), Store.fonts(context), scale)
            val rv = RemoteViews(context.packageName, R.layout.widget)
            rv.setImageViewBitmap(R.id.widget_image, bmp)
            rv.setContentDescription(R.id.widget_image, "${Art.LABELS[model.key]}, ${model.temp.toInt()} degrees. ${model.advice}")
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.widget_image, open)
            return rv
        }
    }
}
